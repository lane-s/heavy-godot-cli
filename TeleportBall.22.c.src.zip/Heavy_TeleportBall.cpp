/**
 * Copyright (c) 2017 Enzien Audio, Ltd.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions, and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the phrase "powered by heavy",
 *    the heavy logo, and a hyperlink to https://enzienaudio.com, all in a visible
 *    form.
 * 
 *   2.1 If the Application is distributed in a store system (for example,
 *       the Apple "App Store" or "Google Play"), the phrase "powered by heavy"
 *       shall be included in the app description or the copyright text as well as
 *       the in the app itself. The heavy logo will shall be visible in the app
 *       itself as well.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

#include "Heavy_TeleportBall.hpp"

#define Context(_c) reinterpret_cast<Heavy_TeleportBall *>(_c)



/*
 * C Functions
 */

extern "C" {
  HV_EXPORT HeavyContextInterface *hv_TeleportBall_new(double sampleRate) {
    return new Heavy_TeleportBall(sampleRate);
  }

  HV_EXPORT HeavyContextInterface *hv_TeleportBall_new_with_options(double sampleRate,
      int poolKb, int inQueueKb, int outQueueKb) {
    return new Heavy_TeleportBall(sampleRate, poolKb, inQueueKb, outQueueKb);
  }
} // extern "C"







/*
 * Class Functions
 */

Heavy_TeleportBall::Heavy_TeleportBall(double sampleRate, int poolKb, int inQueueKb, int outQueueKb)
    : HeavyContext(sampleRate, poolKb, inQueueKb, outQueueKb) {
  numBytes += sLine_init(&sLine_3BIk5tuC);
  numBytes += sLine_init(&sLine_htu4mGqn);
  numBytes += sPhasor_init(&sPhasor_ZYVTR0ew, sampleRate);
  numBytes += sLine_init(&sLine_ihNLSowx);
  numBytes += sLine_init(&sLine_jkuUC7Tj);
  numBytes += sLine_init(&sLine_HipFyj6H);
  numBytes += sLine_init(&sLine_r8PzBIdi);
  numBytes += sBiquad_init(&sBiquad_s_4kPgLwqC);
  numBytes += sPhasor_init(&sPhasor_3RDIogJb, sampleRate);
  numBytes += sLine_init(&sLine_Rqaou0AQ);
  numBytes += sLine_init(&sLine_7wTQBa0D);
  numBytes += sLine_init(&sLine_PiRttfo4);
  numBytes += sLine_init(&sLine_oIl3yJVk);
  numBytes += sBiquad_init(&sBiquad_s_oUsyc82S);
  numBytes += sLine_init(&sLine_X9Xow5lV);
  numBytes += sLine_init(&sLine_RdIOWs8G);
  numBytes += sLine_init(&sLine_VtvTj2K0);
  numBytes += sLine_init(&sLine_prekwjOa);
  numBytes += sBiquad_init(&sBiquad_s_xhaLKDWS);
  numBytes += sCPole_init(&sCPole_bJKvXMeV);
  numBytes += sLine_init(&sLine_zeqOyzLe);
  numBytes += sLine_init(&sLine_L8dmUZEV);
  numBytes += sLine_init(&sLine_nTcQZRMR);
  numBytes += sLine_init(&sLine_ZPWmyEJc);
  numBytes += sLine_init(&sLine_SDjZH5kX);
  numBytes += sBiquad_init(&sBiquad_s_tljOXXkI);
  numBytes += cVar_init_f(&cVar_Lfx0rAEr, 1.7f);
  numBytes += cBinop_init(&cBinop_dXOfcdId, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_vwup37vl, 44100.0f); // __div
  numBytes += cBinop_init(&cBinop_Sh7ph9ti, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_XWmDfgtb, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_aYcLxxxr, 0.0f); // __mul
  numBytes += cVar_init_f(&cVar_g4GdS8iX, 0.0f);
  numBytes += cVar_init_f(&cVar_FKBBBAR5, 900.0f);
  numBytes += cBinop_init(&cBinop_CxLzDeXX, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_L9lBm0ue, 0.0f); // __mul
  numBytes += cPack_init(&cPack_VSNNml8h, 2, 0.0f, 0.0f);
  numBytes += cIf_init(&cIf_gmKrHUzz, false);
  numBytes += cVar_init_f(&cVar_0tR3sQT5, 0.0f);
  numBytes += cSlice_init(&cSlice_MwdLVmZT, 2, 1);
  numBytes += cSlice_init(&cSlice_kbEIxkZp, 1, 1);
  numBytes += cSlice_init(&cSlice_R3aZIyfA, 0, 1);
  numBytes += cDelay_init(this, &cDelay_aWqnKevK, 0.0f);
  numBytes += cDelay_init(this, &cDelay_gcQobKk4, 0.0f);
  numBytes += cSlice_init(&cSlice_sTk8Q7jb, 1, -1);
  numBytes += cPack_init(&cPack_PUqLM2Y4, 2, 0.0f, 0.0f);
  numBytes += cSlice_init(&cSlice_hS25Fnl4, 2, 1);
  numBytes += cSlice_init(&cSlice_arzukhbO, 0, 1);
  numBytes += cSlice_init(&cSlice_I8I3o5UP, 1, 1);
  numBytes += cDelay_init(this, &cDelay_LKxTSjxa, 0.0f);
  numBytes += cDelay_init(this, &cDelay_vMyjUVWR, 0.0f);
  numBytes += cPack_init(&cPack_svPqxpLB, 2, 0.0f, 0.0f);
  numBytes += cSlice_init(&cSlice_DCrbpKyx, 1, -1);
  numBytes += sVarf_init(&sVarf_sBOxIsvp, 1.0f, 0.0f, false);
  numBytes += cVar_init_f(&cVar_sIAxFxzp, 0.0f);
  numBytes += cVar_init_f(&cVar_a4k3tjwo, 900.0f);
  numBytes += cBinop_init(&cBinop_A4dQsGaq, 0.0f); // __mul
  numBytes += cVar_init_f(&cVar_9aTQX5vq, 0.0f);
  numBytes += cBinop_init(&cBinop_Eq1pYkSe, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_z1w195Xs, 0.0f); // __mul
  numBytes += cVar_init_f(&cVar_dFndJ8OR, 1.2f);
  numBytes += cBinop_init(&cBinop_LnsWlzJH, 44100.0f); // __div
  numBytes += cBinop_init(&cBinop_DcZ77MMQ, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_zH6rtcKb, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_szmGTraU, 0.0f); // __mul
  numBytes += sVarf_init(&sVarf_x0siIQAg, 0.0f, 0.0f, false);
  numBytes += cIf_init(&cIf_9myDFGq1, false);
  numBytes += sVarf_init(&sVarf_VIsgxGDe, 0.0f, 0.0f, false);
  numBytes += cVar_init_f(&cVar_e8i7ikdJ, 0.75f);
  numBytes += sVarf_init(&sVarf_OJeEqbrq, 0.0f, 0.0f, false);
  numBytes += sVarf_init(&sVarf_jWrRCMWD, 1.0f, 0.0f, false);
  numBytes += cVar_init_f(&cVar_kh3s0X0s, 0.0f);
  numBytes += sVarf_init(&sVarf_uZg1LdCU, 22.0f, 0.0f, false);
  numBytes += cPack_init(&cPack_iSjhGGK3, 2, 0.0f, 0.0f);
  numBytes += cBinop_init(&cBinop_hWrG8tO1, 0.0f); // __gt
  numBytes += cVar_init_f(&cVar_UwJ7QkVQ, 0.0f);
  numBytes += cBinop_init(&cBinop_jV9Z6zac, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_WN6f41Wd, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_jDj3BYcv, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_w8MTAghT, 44100.0f); // __div
  numBytes += cBinop_init(&cBinop_a3wzdxTY, 0.0f); // __mul
  numBytes += cVar_init_f(&cVar_5Un0TOof, 1.2f);
  numBytes += cVar_init_f(&cVar_iNg3835t, 700.0f);
  numBytes += cBinop_init(&cBinop_4Yxm9i4b, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_4z9eXqNG, 0.0f); // __mul
  numBytes += cIf_init(&cIf_3MraED15, false);
  numBytes += cBinop_init(&cBinop_JrT8uNHz, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_SWvtpRvw, 0.0f); // __mul
  numBytes += cVar_init_f(&cVar_4NASTmHD, 0.0f);
  numBytes += cVar_init_f(&cVar_7b01B6cc, 1.0f);
  numBytes += cBinop_init(&cBinop_BDUr3vbX, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_kQaB4sRO, 44100.0f); // __div
  numBytes += cBinop_init(&cBinop_kbDxjCiu, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_JcSaZ0Se, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_kTfIaSgM, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_oEhXBjfj, 0.0f); // __mul
  numBytes += cVar_init_f(&cVar_hQOfRmBD, 50.0f);
  numBytes += cPack_init(&cPack_O4GkEa9c, 2, 0.0f, 0.0f);
  numBytes += cVar_init_f(&cVar_JbCyKESI, 0.0f);
  numBytes += cPack_init(&cPack_31MA3hV9, 2, 0.0f, 0.0f);
  numBytes += sVarf_init(&sVarf_itU2SQRj, 20.0f, 0.0f, false);
  numBytes += cIf_init(&cIf_7gMJV94X, false);
  
  // schedule a message to trigger all loadbangs via the __hv_init receiver
  scheduleMessageForReceiver(0xCE5CC65B, msg_initWithBang(HV_MESSAGE_ON_STACK(1), 0));
}

Heavy_TeleportBall::~Heavy_TeleportBall() {
  cPack_free(&cPack_VSNNml8h);
  cPack_free(&cPack_PUqLM2Y4);
  cPack_free(&cPack_svPqxpLB);
  cPack_free(&cPack_iSjhGGK3);
  cPack_free(&cPack_O4GkEa9c);
  cPack_free(&cPack_31MA3hV9);
}

HvTable *Heavy_TeleportBall::getTableForHash(hv_uint32_t tableHash) {
  return nullptr;
}

void Heavy_TeleportBall::scheduleMessageForReceiver(hv_uint32_t receiverHash, HvMessage *m) {
  switch (receiverHash) {
    case 0xC489693B: { // 1052-alpha
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_DaewGX2E_sendMessage);
      break;
    }
    case 0x7BE371FD: { // 1052-wcos
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_KTOzvjWU_sendMessage);
      break;
    }
    case 0x8B326FB1: { // 1052-wsin
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_VyIHX9yL_sendMessage);
      break;
    }
    case 0x94F93E04: { // 1089-alpha
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_yqJcAwHz_sendMessage);
      break;
    }
    case 0xEEADE586: { // 1089-wcos
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_FeyyYctG_sendMessage);
      break;
    }
    case 0xBCA0CAFA: { // 1089-wsin
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_dwFCxkVs_sendMessage);
      break;
    }
    case 0xFA9B416: { // 1126-alpha
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_XGPw1LC7_sendMessage);
      break;
    }
    case 0x5DFEA941: { // 1126-wcos
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_clKMGLFi_sendMessage);
      break;
    }
    case 0xC574D7F: { // 1126-wsin
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_82DNXZ6h_sendMessage);
      break;
    }
    case 0x37B429F7: { // 1164-alpha
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_zbXeDxai_sendMessage);
      break;
    }
    case 0x9438080: { // 1164-wcos
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_0RC3qZ6X_sendMessage);
      break;
    }
    case 0xA1C57750: { // 1164-wsin
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_zsSUm1O6_sendMessage);
      break;
    }
    case 0xCE5CC65B: { // __hv_init
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_IMc9rMg6_sendMessage);
      break;
    }
    case 0x96BBCF1: { // deploy
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_9Y3DSjfc_sendMessage);
      break;
    }
    case 0x40EFA271: { // off
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_DRntEOA2_sendMessage);
      break;
    }
    case 0xC5E77367: { // on
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_TaWyDur0_sendMessage);
      break;
    }
    case 0x71E5F6FB: { // output_gain
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_OPDQ6QBz_sendMessage);
      break;
    }
    case 0x3F5E99AA: { // ramp_time
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_1jUWTkpJ_sendMessage);
      break;
    }
    case 0x13A7A14A: { // stationary_threshold
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_7m5EjBJc_sendMessage);
      break;
    }
    case 0x5A85518B: { // switch_time
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_yGvKUhrs_sendMessage);
      break;
    }
    case 0x853B1BE7: { // velocity
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_js4EiDCr_sendMessage);
      break;
    }
    default: return;
  }
}

int Heavy_TeleportBall::getParameterInfo(int index, HvParameterInfo *info) {
  if (info != nullptr) {
    switch (index) {
      case 0: {
        info->name = "on";
        info->hash = 0xC5E77367;
        info->type = HvParameterType::HV_PARAM_TYPE_EVENT_IN;
        info->minVal = 0.0f;
        info->maxVal = 0.0f;
        info->defaultVal = 0.0f;
        break;
      }
      case 1: {
        info->name = "off";
        info->hash = 0x40EFA271;
        info->type = HvParameterType::HV_PARAM_TYPE_EVENT_IN;
        info->minVal = 0.0f;
        info->maxVal = 0.0f;
        info->defaultVal = 0.0f;
        break;
      }
      case 2: {
        info->name = "deploy";
        info->hash = 0x96BBCF1;
        info->type = HvParameterType::HV_PARAM_TYPE_EVENT_IN;
        info->minVal = 0.0f;
        info->maxVal = 0.0f;
        info->defaultVal = 0.0f;
        break;
      }
      case 3: {
        info->name = "output_gain";
        info->hash = 0x71E5F6FB;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 0.0f;
        info->maxVal = 3.0f;
        info->defaultVal = 1.5f;
        break;
      }
      case 4: {
        info->name = "switch_time";
        info->hash = 0x5A85518B;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 0.0f;
        info->maxVal = 1000.0f;
        info->defaultVal = 100.0f;
        break;
      }
      case 5: {
        info->name = "stationary_threshold";
        info->hash = 0x13A7A14A;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 0.0f;
        info->maxVal = 1.0f;
        info->defaultVal = 0.1f;
        break;
      }
      case 6: {
        info->name = "ramp_time";
        info->hash = 0x3F5E99AA;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 0.0f;
        info->maxVal = 3000.0f;
        info->defaultVal = 1000.0f;
        break;
      }
      case 7: {
        info->name = "velocity";
        info->hash = 0x853B1BE7;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 0.0f;
        info->maxVal = 1.0f;
        info->defaultVal = 0.0f;
        break;
      }
      default: {
        info->name = "invalid parameter index";
        info->hash = 0;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 0.0f;
        info->maxVal = 0.0f;
        info->defaultVal = 0.0f;
        break;
      }
    }
  }
  return 8;
}



/*
 * Send Function Implementations
 */


void Heavy_TeleportBall::cMsg_w3f8uc9t_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 0.0f);
  cSwitchcase_mMrL2wGE_onMessage(_c, NULL, 0, m, NULL);
}

void Heavy_TeleportBall::cReceive_82DNXZ6h_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 0.5f, 0, m, &cBinop_ZCYIx7xS_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -0.5f, 0, m, &cBinop_vTWqGtOr_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_XWmDfgtb, HV_BINOP_MULTIPLY, 0, m, &cBinop_XWmDfgtb_sendMessage);
}

void Heavy_TeleportBall::cMsg_wwOC2VXz_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_prekwjOa, 0, m, NULL);
}

void Heavy_TeleportBall::cSend_PLmSH0Jx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_82DNXZ6h_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_ZCYIx7xS_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_dXOfcdId, HV_BINOP_MULTIPLY, 1, m, &cBinop_dXOfcdId_sendMessage);
}

void Heavy_TeleportBall::cSend_Ezj8jaOX_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_clKMGLFi_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_yqmNPNQU_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_CxLzDeXX, HV_BINOP_MULTIPLY, 1, m, &cBinop_CxLzDeXX_sendMessage);
}

void Heavy_TeleportBall::cCast_GWVNFmn3_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_Lfx0rAEr, 1, m, &cVar_Lfx0rAEr_sendMessage);
}

void Heavy_TeleportBall::cVar_Lfx0rAEr_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 100.0f, 0, m, &cBinop_jLvlD3zQ_sendMessage);
}

void Heavy_TeleportBall::cBinop_dXOfcdId_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_tQCKTmWs_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_KL7OAU0P_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_g4GdS8iX, 1, m, &cVar_g4GdS8iX_sendMessage);
}

void Heavy_TeleportBall::cCast_tC2Mvb3N_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_L9lBm0ue, HV_BINOP_MULTIPLY, 0, m, &cBinop_L9lBm0ue_sendMessage);
}

void Heavy_TeleportBall::cBinop_vwup37vl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_Sh7ph9ti, HV_BINOP_MULTIPLY, 1, m, &cBinop_Sh7ph9ti_sendMessage);
}

void Heavy_TeleportBall::cMsg_o1L1QEGy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  cUnop_onMessage(_c, HV_UNOP_ATAN, m, &cUnop_qbtiX9kN_sendMessage);
}

void Heavy_TeleportBall::cCast_AYw6kINO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_o1L1QEGy_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cUnop_qbtiX9kN_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 8.0f, 0, m, &cBinop_ZesanPwV_sendMessage);
}

void Heavy_TeleportBall::cSystem_LWDaeVqG_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_vwup37vl, HV_BINOP_DIVIDE, 1, m, &cBinop_vwup37vl_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_AYw6kINO_sendMessage);
}

void Heavy_TeleportBall::cMsg_noz6ptHJ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "samplerate");
  cSystem_onMessage(_c, NULL, 0, m, &cSystem_LWDaeVqG_sendMessage);
}

void Heavy_TeleportBall::cBinop_ZesanPwV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_vwup37vl, HV_BINOP_DIVIDE, 0, m, &cBinop_vwup37vl_sendMessage);
}

void Heavy_TeleportBall::cBinop_Sh7ph9ti_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_NgfxZZit_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_GyYIfoqw_sendMessage);
}

void Heavy_TeleportBall::cBinop_1jaiDFf6_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_XWmDfgtb, HV_BINOP_MULTIPLY, 1, m, &cBinop_XWmDfgtb_sendMessage);
}

void Heavy_TeleportBall::cMsg_4Lp4ujSd_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 0.0f, 0, m, &cBinop_pkyFio8R_sendMessage);
}

void Heavy_TeleportBall::cBinop_pkyFio8R_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_aYcLxxxr, HV_BINOP_MULTIPLY, 1, m, &cBinop_aYcLxxxr_sendMessage);
}

void Heavy_TeleportBall::cCast_eBHP9pD1_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_FKBBBAR5, 0, m, &cVar_FKBBBAR5_sendMessage);
}

void Heavy_TeleportBall::cBinop_HE2qP74u_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 20.0f, 0, m, &cBinop_3M50AAh0_sendMessage);
}

void Heavy_TeleportBall::cBinop_3M50AAh0_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_Sh7ph9ti, HV_BINOP_MULTIPLY, 0, m, &cBinop_Sh7ph9ti_sendMessage);
}

void Heavy_TeleportBall::cBinop_vTWqGtOr_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_L9lBm0ue, HV_BINOP_MULTIPLY, 1, m, &cBinop_L9lBm0ue_sendMessage);
}

void Heavy_TeleportBall::cMsg_JltIlWxA_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_1jaiDFf6_sendMessage);
}

void Heavy_TeleportBall::cBinop_em5oHb0X_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_Pmm51PBw_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_gMo7XT1S_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_tC2Mvb3N_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_C31TVD7v_sendMessage);
}

void Heavy_TeleportBall::cMsg_pPtLrQhl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_em5oHb0X_sendMessage);
}

void Heavy_TeleportBall::cSend_n5QWtV3R_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_XGPw1LC7_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_XWmDfgtb_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 0.5f, 0, m, &cBinop_ifafc6l9_sendMessage);
}

void Heavy_TeleportBall::cCast_Pmm51PBw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_aYcLxxxr, HV_BINOP_MULTIPLY, 0, m, &cBinop_aYcLxxxr_sendMessage);
}

void Heavy_TeleportBall::cUnop_2qXEVYyF_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_Ezj8jaOX_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_nN2m0tfE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_g4GdS8iX, 0, m, &cVar_g4GdS8iX_sendMessage);
}

void Heavy_TeleportBall::cCast_HWAqLTmU_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_Lfx0rAEr, 0, m, &cVar_Lfx0rAEr_sendMessage);
}

void Heavy_TeleportBall::cBinop_aYcLxxxr_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_wwOC2VXz_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cVar_g4GdS8iX_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_pPtLrQhl_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_GyYIfoqw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_COS, m, &cUnop_2qXEVYyF_sendMessage);
}

void Heavy_TeleportBall::cVar_FKBBBAR5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_HWAqLTmU_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 20000.0f, 0, m, &cBinop_HE2qP74u_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_nN2m0tfE_sendMessage);
}

void Heavy_TeleportBall::cUnop_HGsW9QNc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_PLmSH0Jx_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_ifafc6l9_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_n5QWtV3R_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_gMo7XT1S_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_CxLzDeXX, HV_BINOP_MULTIPLY, 0, m, &cBinop_CxLzDeXX_sendMessage);
}

void Heavy_TeleportBall::cBinop_Z7wKOoio_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_JltIlWxA_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_jLvlD3zQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_Z7wKOoio_sendMessage);
}

void Heavy_TeleportBall::cBinop_CxLzDeXX_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_TKkjGUBE_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_NgfxZZit_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_SIN, m, &cUnop_HGsW9QNc_sendMessage);
}

void Heavy_TeleportBall::cCast_C31TVD7v_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_dXOfcdId, HV_BINOP_MULTIPLY, 0, m, &cBinop_dXOfcdId_sendMessage);
}

void Heavy_TeleportBall::cBinop_L9lBm0ue_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_BaBjaeA3_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cMsg_BaBjaeA3_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_RdIOWs8G, 0, m, NULL);
}

void Heavy_TeleportBall::cMsg_tQCKTmWs_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_X9Xow5lV, 0, m, NULL);
}

void Heavy_TeleportBall::cMsg_TKkjGUBE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_VtvTj2K0, 0, m, NULL);
}

void Heavy_TeleportBall::cReceive_clKMGLFi_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -2.0f, 0, m, &cBinop_yqmNPNQU_sendMessage);
}

void Heavy_TeleportBall::cPack_VSNNml8h_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSwitchcase_mMrL2wGE_onMessage(_c, NULL, 0, m, NULL);
}

void Heavy_TeleportBall::cReceive_OPDQ6QBz_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  sVarf_onMessage(_c, &Context(_c)->sVarf_sBOxIsvp, m);
}

void Heavy_TeleportBall::cIf_gmKrHUzz_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      break;
    }
    case 1: {
      cSwitchcase_mMrL2wGE_onMessage(_c, NULL, 0, m, NULL);
      break;
    }
    default: return;
  }
}

void Heavy_TeleportBall::cVar_0tR3sQT5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_AZ5QPHsp_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cReceive_1jUWTkpJ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cPack_onMessage(_c, &Context(_c)->cPack_iSjhGGK3, 1, m, &cPack_iSjhGGK3_sendMessage);
  cPack_onMessage(_c, &Context(_c)->cPack_O4GkEa9c, 1, m, &cPack_O4GkEa9c_sendMessage);
}

void Heavy_TeleportBall::cCast_WVXVm6ue_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_5RkSaPPE_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cReceive_js4EiDCr_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_hWrG8tO1, HV_BINOP_GREATER_THAN, 0, m, &cBinop_hWrG8tO1_sendMessage);
  cPack_onMessage(_c, &Context(_c)->cPack_iSjhGGK3, 0, m, &cPack_iSjhGGK3_sendMessage);
}

void Heavy_TeleportBall::cReceive_XGPw1LC7_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_KL7OAU0P_sendMessage);
  cMsg_4Lp4ujSd_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cReceive_7m5EjBJc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_hWrG8tO1, HV_BINOP_GREATER_THAN, 1, m, &cBinop_hWrG8tO1_sendMessage);
}

void Heavy_TeleportBall::cSlice_MwdLVmZT_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      cDelay_onMessage(_c, &Context(_c)->cDelay_aWqnKevK, 1, m, &cDelay_aWqnKevK_sendMessage);
      cDelay_onMessage(_c, &Context(_c)->cDelay_gcQobKk4, 1, m, &cDelay_gcQobKk4_sendMessage);
      break;
    }
    case 1: {
      break;
    }
    default: return;
  }
}

void Heavy_TeleportBall::cSlice_kbEIxkZp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      cDelay_onMessage(_c, &Context(_c)->cDelay_gcQobKk4, 0, m, &cDelay_gcQobKk4_sendMessage);
      break;
    }
    case 1: {
      break;
    }
    default: return;
  }
}

void Heavy_TeleportBall::cSlice_R3aZIyfA_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      cDelay_onMessage(_c, &Context(_c)->cDelay_aWqnKevK, 0, m, &cDelay_aWqnKevK_sendMessage);
      cDelay_onMessage(_c, &Context(_c)->cDelay_gcQobKk4, 0, m, &cDelay_gcQobKk4_sendMessage);
      break;
    }
    case 1: {
      break;
    }
    default: return;
  }
}

void Heavy_TeleportBall::cDelay_aWqnKevK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const m) {
  cDelay_clearExecutingMessage(&Context(_c)->cDelay_aWqnKevK, m);
  cPack_onMessage(_c, &Context(_c)->cPack_PUqLM2Y4, 0, m, &cPack_PUqLM2Y4_sendMessage);
}

void Heavy_TeleportBall::cDelay_gcQobKk4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const m) {
  cDelay_clearExecutingMessage(&Context(_c)->cDelay_gcQobKk4, m);
  cPack_onMessage(_c, &Context(_c)->cPack_PUqLM2Y4, 1, m, &cPack_PUqLM2Y4_sendMessage);
}

void Heavy_TeleportBall::cSlice_sTk8Q7jb_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_16KbS7mp_sendMessage);
      cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_Bu0o2DHa_sendMessage);
      break;
    }
    case 1: {
      cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_16KbS7mp_sendMessage);
      cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_Bu0o2DHa_sendMessage);
      break;
    }
    default: return;
  }
}

void Heavy_TeleportBall::cSwitchcase_mMrL2wGE_onMessage(HeavyContextInterface *_c, void *o, int letIn, const HvMessage *const m, void *sendMessage) {
  switch (msg_getHash(m, 0)) {
    case 0x7A5B032D: { // "stop"
      cSlice_onMessage(_c, &Context(_c)->cSlice_sTk8Q7jb, 0, m, &cSlice_sTk8Q7jb_sendMessage);
      break;
    }
    default: {
      cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_i5MUuuye_sendMessage);
      cSlice_onMessage(_c, &Context(_c)->cSlice_MwdLVmZT, 0, m, &cSlice_MwdLVmZT_sendMessage);
      cSlice_onMessage(_c, &Context(_c)->cSlice_kbEIxkZp, 0, m, &cSlice_kbEIxkZp_sendMessage);
      cSlice_onMessage(_c, &Context(_c)->cSlice_R3aZIyfA, 0, m, &cSlice_R3aZIyfA_sendMessage);
      break;
    }
  }
}

void Heavy_TeleportBall::cCast_Bu0o2DHa_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_GqdWIOl9_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_16KbS7mp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_IYWne96E_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_i5MUuuye_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_ZKfJvczw_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cMsg_IYWne96E_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "clear");
  cDelay_onMessage(_c, &Context(_c)->cDelay_aWqnKevK, 0, m, &cDelay_aWqnKevK_sendMessage);
  cDelay_onMessage(_c, &Context(_c)->cDelay_gcQobKk4, 0, m, &cDelay_gcQobKk4_sendMessage);
  cDelay_onMessage(_c, &Context(_c)->cDelay_gcQobKk4, 0, m, &cDelay_gcQobKk4_sendMessage);
}

void Heavy_TeleportBall::cPack_PUqLM2Y4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  sLine_onMessage(_c, &Context(_c)->sLine_3BIk5tuC, 0, m, NULL);
}

void Heavy_TeleportBall::cMsg_GqdWIOl9_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "stop");
  sLine_onMessage(_c, &Context(_c)->sLine_3BIk5tuC, 0, m, NULL);
}

void Heavy_TeleportBall::cMsg_ZKfJvczw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 0.0f);
  cDelay_onMessage(_c, &Context(_c)->cDelay_aWqnKevK, 1, m, &cDelay_aWqnKevK_sendMessage);
  cDelay_onMessage(_c, &Context(_c)->cDelay_gcQobKk4, 1, m, &cDelay_gcQobKk4_sendMessage);
}

void Heavy_TeleportBall::cSend_EfhIFd8e_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_js4EiDCr_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_A4jfLzwK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_BhRA7AQu_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cMsg_BhRA7AQu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "clear");
  cDelay_onMessage(_c, &Context(_c)->cDelay_LKxTSjxa, 0, m, &cDelay_LKxTSjxa_sendMessage);
  cDelay_onMessage(_c, &Context(_c)->cDelay_vMyjUVWR, 0, m, &cDelay_vMyjUVWR_sendMessage);
  cDelay_onMessage(_c, &Context(_c)->cDelay_vMyjUVWR, 0, m, &cDelay_vMyjUVWR_sendMessage);
}

void Heavy_TeleportBall::cMsg_epua4QIc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 0.0f);
  cDelay_onMessage(_c, &Context(_c)->cDelay_LKxTSjxa, 1, m, &cDelay_LKxTSjxa_sendMessage);
  cDelay_onMessage(_c, &Context(_c)->cDelay_vMyjUVWR, 1, m, &cDelay_vMyjUVWR_sendMessage);
}

void Heavy_TeleportBall::cMsg_z2yWeDaq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "stop");
  sLine_onMessage(_c, &Context(_c)->sLine_htu4mGqn, 0, m, NULL);
}

void Heavy_TeleportBall::cSlice_hS25Fnl4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      cDelay_onMessage(_c, &Context(_c)->cDelay_LKxTSjxa, 1, m, &cDelay_LKxTSjxa_sendMessage);
      cDelay_onMessage(_c, &Context(_c)->cDelay_vMyjUVWR, 1, m, &cDelay_vMyjUVWR_sendMessage);
      break;
    }
    case 1: {
      break;
    }
    default: return;
  }
}

void Heavy_TeleportBall::cSlice_arzukhbO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      cDelay_onMessage(_c, &Context(_c)->cDelay_LKxTSjxa, 0, m, &cDelay_LKxTSjxa_sendMessage);
      cDelay_onMessage(_c, &Context(_c)->cDelay_vMyjUVWR, 0, m, &cDelay_vMyjUVWR_sendMessage);
      break;
    }
    case 1: {
      break;
    }
    default: return;
  }
}

void Heavy_TeleportBall::cSlice_I8I3o5UP_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      cDelay_onMessage(_c, &Context(_c)->cDelay_vMyjUVWR, 0, m, &cDelay_vMyjUVWR_sendMessage);
      break;
    }
    case 1: {
      break;
    }
    default: return;
  }
}

void Heavy_TeleportBall::cDelay_LKxTSjxa_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const m) {
  cDelay_clearExecutingMessage(&Context(_c)->cDelay_LKxTSjxa, m);
  cPack_onMessage(_c, &Context(_c)->cPack_svPqxpLB, 0, m, &cPack_svPqxpLB_sendMessage);
}

void Heavy_TeleportBall::cDelay_vMyjUVWR_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const m) {
  cDelay_clearExecutingMessage(&Context(_c)->cDelay_vMyjUVWR, m);
  cPack_onMessage(_c, &Context(_c)->cPack_svPqxpLB, 1, m, &cPack_svPqxpLB_sendMessage);
}

void Heavy_TeleportBall::cCast_TXSJyZoP_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_z2yWeDaq_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_82Xq78GC_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_epua4QIc_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cPack_svPqxpLB_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  sLine_onMessage(_c, &Context(_c)->sLine_htu4mGqn, 0, m, NULL);
}

void Heavy_TeleportBall::cSlice_DCrbpKyx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_A4jfLzwK_sendMessage);
      cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_TXSJyZoP_sendMessage);
      break;
    }
    case 1: {
      cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_A4jfLzwK_sendMessage);
      cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_TXSJyZoP_sendMessage);
      break;
    }
    default: return;
  }
}

void Heavy_TeleportBall::cSwitchcase_rIYs7urM_onMessage(HeavyContextInterface *_c, void *o, int letIn, const HvMessage *const m, void *sendMessage) {
  switch (msg_getHash(m, 0)) {
    case 0x7A5B032D: { // "stop"
      cSlice_onMessage(_c, &Context(_c)->cSlice_DCrbpKyx, 0, m, &cSlice_DCrbpKyx_sendMessage);
      break;
    }
    default: {
      cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_82Xq78GC_sendMessage);
      cSlice_onMessage(_c, &Context(_c)->cSlice_hS25Fnl4, 0, m, &cSlice_hS25Fnl4_sendMessage);
      cSlice_onMessage(_c, &Context(_c)->cSlice_I8I3o5UP, 0, m, &cSlice_I8I3o5UP_sendMessage);
      cSlice_onMessage(_c, &Context(_c)->cSlice_arzukhbO, 0, m, &cSlice_arzukhbO_sendMessage);
      break;
    }
  }
}

void Heavy_TeleportBall::cReceive_DRntEOA2_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_cGwgCMrL_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cReceive_zbXeDxai_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_Dmt2TUv1_sendMessage);
  cMsg_PycDS2L7_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cMsg_i7E52hIg_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 2.0f);
  cVar_onMessage(_c, &Context(_c)->cVar_sIAxFxzp, 0, m, &cVar_sIAxFxzp_sendMessage);
}

void Heavy_TeleportBall::cReceive_0RC3qZ6X_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_uSFVqd4M_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_PSGQhwRx_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_D0P8zlpk_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -2.0f, 0, m, &cBinop_PhrdMM6s_sendMessage);
}

void Heavy_TeleportBall::cVar_sIAxFxzp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_gmKrHUzz, 1, m, &cIf_gmKrHUzz_sendMessage);
  cSwitchcase_tblpyBs1_onMessage(_c, NULL, 0, m, NULL);
  cSwitchcase_rPrbrE0V_onMessage(_c, NULL, 0, m, NULL);
  cSwitchcase_nwqLQLR2_onMessage(_c, NULL, 0, m, NULL);
}

void Heavy_TeleportBall::cBinop_7Ttef5ai_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_7gMJV94X, 1, m, &cIf_7gMJV94X_sendMessage);
  cSwitchcase_stmrrEFP_onMessage(_c, NULL, 0, m, NULL);
}

void Heavy_TeleportBall::cMsg_5RkSaPPE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 0.5f);
  cPack_onMessage(_c, &Context(_c)->cPack_VSNNml8h, 0, m, &cPack_VSNNml8h_sendMessage);
}

void Heavy_TeleportBall::cMsg_Jlz9PQJ1_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 0.0f);
  cPack_onMessage(_c, &Context(_c)->cPack_31MA3hV9, 0, m, &cPack_31MA3hV9_sendMessage);
  cSwitchcase_rIYs7urM_onMessage(_c, NULL, 0, m, NULL);
}

void Heavy_TeleportBall::cCast_OdipQyG1_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_Jlz9PQJ1_sendMessage(_c, 0, m);
  cMsg_TusoicN1_sendMessage(_c, 0, m);
  cMsg_3CUSSnbQ_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cSwitchcase_tblpyBs1_onMessage(HeavyContextInterface *_c, void *o, int letIn, const HvMessage *const m, void *sendMessage) {
  switch (msg_getHash(m, 0)) {
    case 0x0: { // "0.0"
      cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_OdipQyG1_sendMessage);
      break;
    }
    default: {
      break;
    }
  }
}

void Heavy_TeleportBall::cSend_aOCpubki_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_1jUWTkpJ_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cReceive_dwFCxkVs_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 0.5f, 0, m, &cBinop_QZs27cA0_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -0.5f, 0, m, &cBinop_GsrfCnwQ_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_szmGTraU, HV_BINOP_MULTIPLY, 0, m, &cBinop_szmGTraU_sendMessage);
}

void Heavy_TeleportBall::cReceive_9Y3DSjfc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_i7E52hIg_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cReceive_KTOzvjWU_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -2.0f, 0, m, &cBinop_BwnrwR5k_sendMessage);
}

void Heavy_TeleportBall::cCast_VFrETBtw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_Malmsda4_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cSwitchcase_nwqLQLR2_onMessage(HeavyContextInterface *_c, void *o, int letIn, const HvMessage *const m, void *sendMessage) {
  switch (msg_getHash(m, 0)) {
    case 0x40000000: { // "2.0"
      cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_VFrETBtw_sendMessage);
      break;
    }
    default: {
      break;
    }
  }
}

void Heavy_TeleportBall::cCast_8Q5Yu2PV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_TeleportBall::cReceive_IMc9rMg6_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_KftY9dVV_sendMessage(_c, 0, m);
  cMsg_2hLYzn7R_sendMessage(_c, 0, m);
  cMsg_noz6ptHJ_sendMessage(_c, 0, m);
  cMsg_RuhtRkJA_sendMessage(_c, 0, m);
  cVar_onMessage(_c, &Context(_c)->cVar_iNg3835t, 0, m, &cVar_iNg3835t_sendMessage);
  cVar_onMessage(_c, &Context(_c)->cVar_a4k3tjwo, 0, m, &cVar_a4k3tjwo_sendMessage);
  cVar_onMessage(_c, &Context(_c)->cVar_FKBBBAR5, 0, m, &cVar_FKBBBAR5_sendMessage);
  cVar_onMessage(_c, &Context(_c)->cVar_hQOfRmBD, 0, m, &cVar_hQOfRmBD_sendMessage);
  cVar_onMessage(_c, &Context(_c)->cVar_e8i7ikdJ, 0, m, &cVar_e8i7ikdJ_sendMessage);
  cMsg_LrUR2CzI_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cMsg_nvAOs0rT_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_Rqaou0AQ, 0, m, NULL);
}

void Heavy_TeleportBall::cMsg_Taugy3Cj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_oIl3yJVk, 0, m, NULL);
}

void Heavy_TeleportBall::cMsg_vUvbIUNA_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_7wTQBa0D, 0, m, NULL);
}

void Heavy_TeleportBall::cBinop_oxFCmiol_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_szmGTraU, HV_BINOP_MULTIPLY, 1, m, &cBinop_szmGTraU_sendMessage);
}

void Heavy_TeleportBall::cBinop_JioTizAy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_9aTQX5vq, 1, m, &cVar_9aTQX5vq_sendMessage);
}

void Heavy_TeleportBall::cVar_a4k3tjwo_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_4uzQdKxl_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 20000.0f, 0, m, &cBinop_qbWvZdC9_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_wWrQEgLO_sendMessage);
}

void Heavy_TeleportBall::cBinop_GsrfCnwQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_Eq1pYkSe, HV_BINOP_MULTIPLY, 1, m, &cBinop_Eq1pYkSe_sendMessage);
}

void Heavy_TeleportBall::cMsg_c6dhhbA8_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_QbUEMo9S_sendMessage);
}

void Heavy_TeleportBall::cUnop_aprhdfzE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_8wLcaQKq_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_4uzQdKxl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_dFndJ8OR, 0, m, &cVar_dFndJ8OR_sendMessage);
}

void Heavy_TeleportBall::cCast_KiNebbwB_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_COS, m, &cUnop_UJnUVoHu_sendMessage);
}

void Heavy_TeleportBall::cBinop_A4dQsGaq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_kBhOwSP8_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_U0DUyy7F_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_zH6rtcKb, HV_BINOP_MULTIPLY, 1, m, &cBinop_zH6rtcKb_sendMessage);
}

void Heavy_TeleportBall::cMsg_bpspVTXl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 0.0f, 0, m, &cBinop_U0DUyy7F_sendMessage);
}

void Heavy_TeleportBall::cCast_wWrQEgLO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_9aTQX5vq, 0, m, &cVar_9aTQX5vq_sendMessage);
}

void Heavy_TeleportBall::cBinop_QbUEMo9S_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_JCalKg8P_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_b35Yu7cQ_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_tYT0A4qM_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_TjbKMWQf_sendMessage);
}

void Heavy_TeleportBall::cBinop_vEb5K4JT_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_A4dQsGaq, HV_BINOP_MULTIPLY, 1, m, &cBinop_A4dQsGaq_sendMessage);
}

void Heavy_TeleportBall::cVar_9aTQX5vq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_c6dhhbA8_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_Eq1pYkSe_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_vUvbIUNA_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_qbWvZdC9_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 20.0f, 0, m, &cBinop_JOvvd9uB_sendMessage);
}

void Heavy_TeleportBall::cBinop_JOvvd9uB_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_DcZ77MMQ, HV_BINOP_MULTIPLY, 0, m, &cBinop_DcZ77MMQ_sendMessage);
}

void Heavy_TeleportBall::cBinop_t5WBEN0j_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_ea7ANKOQ_sendMessage);
}

void Heavy_TeleportBall::cBinop_ea7ANKOQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_RpN79y3D_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_uSPalBDP_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_a4k3tjwo, 0, m, &cVar_a4k3tjwo_sendMessage);
}

void Heavy_TeleportBall::cCast_b35Yu7cQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_A4dQsGaq, HV_BINOP_MULTIPLY, 0, m, &cBinop_A4dQsGaq_sendMessage);
}

void Heavy_TeleportBall::cBinop_z1w195Xs_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_nvAOs0rT_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cMsg_RpN79y3D_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_oxFCmiol_sendMessage);
}

void Heavy_TeleportBall::cCast_TjbKMWQf_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_z1w195Xs, HV_BINOP_MULTIPLY, 0, m, &cBinop_z1w195Xs_sendMessage);
}

void Heavy_TeleportBall::cCast_SKPo7brC_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_SIN, m, &cUnop_aprhdfzE_sendMessage);
}

void Heavy_TeleportBall::cBinop_697dzppX_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_fR1IwSjg_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cVar_dFndJ8OR_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 100.0f, 0, m, &cBinop_t5WBEN0j_sendMessage);
}

void Heavy_TeleportBall::cCast_JCalKg8P_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_zH6rtcKb, HV_BINOP_MULTIPLY, 0, m, &cBinop_zH6rtcKb_sendMessage);
}

void Heavy_TeleportBall::cUnop_UJnUVoHu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_ruS8JkkS_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cSend_fR1IwSjg_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_yqJcAwHz_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cSend_ruS8JkkS_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_FeyyYctG_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_tYT0A4qM_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_Eq1pYkSe, HV_BINOP_MULTIPLY, 0, m, &cBinop_Eq1pYkSe_sendMessage);
}

void Heavy_TeleportBall::cBinop_LnsWlzJH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_DcZ77MMQ, HV_BINOP_MULTIPLY, 1, m, &cBinop_DcZ77MMQ_sendMessage);
}

void Heavy_TeleportBall::cUnop_BBV4Vopy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 8.0f, 0, m, &cBinop_qRFj34tv_sendMessage);
}

void Heavy_TeleportBall::cBinop_DcZ77MMQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_SKPo7brC_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_KiNebbwB_sendMessage);
}

void Heavy_TeleportBall::cCast_RFJWeTsA_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_0znukAQU_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_qRFj34tv_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_LnsWlzJH, HV_BINOP_DIVIDE, 0, m, &cBinop_LnsWlzJH_sendMessage);
}

void Heavy_TeleportBall::cMsg_0znukAQU_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  cUnop_onMessage(_c, HV_UNOP_ATAN, m, &cUnop_BBV4Vopy_sendMessage);
}

void Heavy_TeleportBall::cMsg_2hLYzn7R_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "samplerate");
  cSystem_onMessage(_c, NULL, 0, m, &cSystem_3RPsBVYZ_sendMessage);
}

void Heavy_TeleportBall::cSystem_3RPsBVYZ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_LnsWlzJH, HV_BINOP_DIVIDE, 1, m, &cBinop_LnsWlzJH_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_RFJWeTsA_sendMessage);
}

void Heavy_TeleportBall::cBinop_zH6rtcKb_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_Taugy3Cj_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_QZs27cA0_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_z1w195Xs, HV_BINOP_MULTIPLY, 1, m, &cBinop_z1w195Xs_sendMessage);
}

void Heavy_TeleportBall::cBinop_szmGTraU_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 0.5f, 0, m, &cBinop_697dzppX_sendMessage);
}

void Heavy_TeleportBall::cCast_UU9WqzVA_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_dFndJ8OR, 1, m, &cVar_dFndJ8OR_sendMessage);
}

void Heavy_TeleportBall::cSend_8wLcaQKq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_dwFCxkVs_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cMsg_kBhOwSP8_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_PiRttfo4, 0, m, NULL);
}

void Heavy_TeleportBall::cMsg_3CUSSnbQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 20.0f);
  sVarf_onMessage(_c, &Context(_c)->sVarf_itU2SQRj, m);
}

void Heavy_TeleportBall::cMsg_cGwgCMrL_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 0.0f);
  cVar_onMessage(_c, &Context(_c)->cVar_sIAxFxzp, 0, m, &cVar_sIAxFxzp_sendMessage);
}

void Heavy_TeleportBall::cReceive_TaWyDur0_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_th8YOBMO_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cReceive_DaewGX2E_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_8Bn25wa4_sendMessage);
  cMsg_ogFMhdoM_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cMsg_Pk7qACNR_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setElementToFrom(m, 1, n, 1);
  cIf_onMessage(_c, &Context(_c)->cIf_3MraED15, 0, m, &cIf_3MraED15_sendMessage);
}

void Heavy_TeleportBall::cSystem_OBssJCLw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_BlOcrObY_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cMsg_LrUR2CzI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "samplerate");
  cSystem_onMessage(_c, NULL, 0, m, &cSystem_OBssJCLw_sendMessage);
}

void Heavy_TeleportBall::cMsg_2TfT4H55_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_QvTopjNc_sendMessage);
}

void Heavy_TeleportBall::cMsg_TfDGKBH4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 2.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_tZsSKStj_sendMessage);
}

void Heavy_TeleportBall::cBinop_VomAosSo_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  sVarf_onMessage(_c, &Context(_c)->sVarf_x0siIQAg, m);
}

void Heavy_TeleportBall::cBinop_tZsSKStj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_DLtrZPqt_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_QvTopjNc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  sVarf_onMessage(_c, &Context(_c)->sVarf_jWrRCMWD, m);
  sVarf_onMessage(_c, &Context(_c)->sVarf_OJeEqbrq, m);
}

void Heavy_TeleportBall::cBinop_W84Dt2DB_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_9myDFGq1, 1, m, &cIf_9myDFGq1_sendMessage);
}

void Heavy_TeleportBall::cIf_9myDFGq1_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      cMsg_C2VS2hKI_sendMessage(_c, 0, m);
      break;
    }
    case 1: {
      cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 2.0f, 0, m, &cBinop_67YArhNm_sendMessage);
      cMsg_2TfT4H55_sendMessage(_c, 0, m);
      break;
    }
    default: return;
  }
}

void Heavy_TeleportBall::cBinop_Nts84Mzp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  sVarf_onMessage(_c, &Context(_c)->sVarf_VIsgxGDe, m);
}

void Heavy_TeleportBall::cMsg_DLtrZPqt_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 2.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 0.0f, 0, m, &cBinop_VomAosSo_sendMessage);
}

void Heavy_TeleportBall::cMsg_C2VS2hKI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 0.0f);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 2.0f, 0, m, &cBinop_67YArhNm_sendMessage);
  sVarf_onMessage(_c, &Context(_c)->sVarf_jWrRCMWD, m);
  sVarf_onMessage(_c, &Context(_c)->sVarf_OJeEqbrq, m);
}

void Heavy_TeleportBall::cMsg_BlOcrObY_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_Nts84Mzp_sendMessage);
}

void Heavy_TeleportBall::cBinop_67YArhNm_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_TfDGKBH4_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cVar_e8i7ikdJ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_GREATER_THAN_EQL, 1e-05f, 0, m, &cBinop_W84Dt2DB_sendMessage);
  cIf_onMessage(_c, &Context(_c)->cIf_9myDFGq1, 0, m, &cIf_9myDFGq1_sendMessage);
}

void Heavy_TeleportBall::cCast_N1ffwSv4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_EQ, 0.0f, 0, m, &cBinop_7Ttef5ai_sendMessage);
  cIf_onMessage(_c, &Context(_c)->cIf_3MraED15, 1, m, &cIf_3MraED15_sendMessage);
}

void Heavy_TeleportBall::cReceive_yqJcAwHz_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_JioTizAy_sendMessage);
  cMsg_bpspVTXl_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cVar_kh3s0X0s_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_EfhIFd8e_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cMsg_Malmsda4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, -1.0f);
  msg_setFloat(m, 1, 3000.0f);
  cSwitchcase_rIYs7urM_onMessage(_c, NULL, 0, m, NULL);
}

void Heavy_TeleportBall::cPack_iSjhGGK3_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_Pk7qACNR_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cMsg_nkvPCCYS_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 0.5f);
  cPack_onMessage(_c, &Context(_c)->cPack_O4GkEa9c, 0, m, &cPack_O4GkEa9c_sendMessage);
}

void Heavy_TeleportBall::cBinop_hWrG8tO1_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_N1ffwSv4_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_8Q5Yu2PV_sendMessage);
}

void Heavy_TeleportBall::cMsg_TusoicN1_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 22.0f);
  sVarf_onMessage(_c, &Context(_c)->sVarf_uZg1LdCU, m);
}

void Heavy_TeleportBall::cMsg_2C18Qpy8_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_r8PzBIdi, 0, m, NULL);
}

void Heavy_TeleportBall::cMsg_chKYh1P5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_HipFyj6H, 0, m, NULL);
}

void Heavy_TeleportBall::cMsg_pOxlsV5X_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_ihNLSowx, 0, m, NULL);
}

void Heavy_TeleportBall::cMsg_hhOakXu6_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_jkuUC7Tj, 0, m, NULL);
}

void Heavy_TeleportBall::cBinop_sWbdYt1H_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_4Yxm9i4b, HV_BINOP_MULTIPLY, 1, m, &cBinop_4Yxm9i4b_sendMessage);
}

void Heavy_TeleportBall::cUnop_3cRJD2s2_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_dZ3WBkFJ_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cVar_UwJ7QkVQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_NSBFkB38_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_cMmda36N_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_DgN4stpK_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_jV9Z6zac_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_hhOakXu6_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cSend_dZ3WBkFJ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_VyIHX9yL_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_EZoZY4FU_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_5Un0TOof, 0, m, &cVar_5Un0TOof_sendMessage);
}

void Heavy_TeleportBall::cBinop_WN6f41Wd_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_pOxlsV5X_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_jDj3BYcv_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_f4Nb8o1A_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_j7KZwCkW_sendMessage);
}

void Heavy_TeleportBall::cBinop_VEnosIYc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_w8MTAghT, HV_BINOP_DIVIDE, 0, m, &cBinop_w8MTAghT_sendMessage);
}

void Heavy_TeleportBall::cSystem_uwuGlonE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_w8MTAghT, HV_BINOP_DIVIDE, 1, m, &cBinop_w8MTAghT_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_UQSAciSy_sendMessage);
}

void Heavy_TeleportBall::cMsg_KftY9dVV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "samplerate");
  cSystem_onMessage(_c, NULL, 0, m, &cSystem_uwuGlonE_sendMessage);
}

void Heavy_TeleportBall::cCast_UQSAciSy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_LgVp4Rp0_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cMsg_LgVp4Rp0_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  cUnop_onMessage(_c, HV_UNOP_ATAN, m, &cUnop_PyHIGV4D_sendMessage);
}

void Heavy_TeleportBall::cUnop_PyHIGV4D_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 8.0f, 0, m, &cBinop_VEnosIYc_sendMessage);
}

void Heavy_TeleportBall::cBinop_w8MTAghT_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_jDj3BYcv, HV_BINOP_MULTIPLY, 1, m, &cBinop_jDj3BYcv_sendMessage);
}

void Heavy_TeleportBall::cCast_YPujhyNu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_UwJ7QkVQ, 0, m, &cVar_UwJ7QkVQ_sendMessage);
}

void Heavy_TeleportBall::cBinop_hNHiYQmt_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_jV9Z6zac, HV_BINOP_MULTIPLY, 1, m, &cBinop_jV9Z6zac_sendMessage);
}

void Heavy_TeleportBall::cBinop_a3wzdxTY_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_2C18Qpy8_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_IL7rO7KS_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_3adrGwzN_sendMessage);
}

void Heavy_TeleportBall::cBinop_3adrGwzN_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_zwFOBU5k_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_0TMKTEwh_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_jV9Z6zac, HV_BINOP_MULTIPLY, 0, m, &cBinop_jV9Z6zac_sendMessage);
}

void Heavy_TeleportBall::cBinop_Rtz4sBqN_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_a3wzdxTY, HV_BINOP_MULTIPLY, 1, m, &cBinop_a3wzdxTY_sendMessage);
}

void Heavy_TeleportBall::cMsg_ogFMhdoM_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 0.0f, 0, m, &cBinop_Rtz4sBqN_sendMessage);
}

void Heavy_TeleportBall::cUnop_QFVaU75d_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_7Fd4Pgai_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cMsg_zwFOBU5k_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_sWbdYt1H_sendMessage);
}

void Heavy_TeleportBall::cCast_l4BGClOj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_4z9eXqNG, HV_BINOP_MULTIPLY, 0, m, &cBinop_4z9eXqNG_sendMessage);
}

void Heavy_TeleportBall::cCast_j7KZwCkW_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_COS, m, &cUnop_QFVaU75d_sendMessage);
}

void Heavy_TeleportBall::cCast_jLgAdgUB_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_WN6f41Wd, HV_BINOP_MULTIPLY, 0, m, &cBinop_WN6f41Wd_sendMessage);
}

void Heavy_TeleportBall::cVar_5Un0TOof_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 100.0f, 0, m, &cBinop_IL7rO7KS_sendMessage);
}

void Heavy_TeleportBall::cVar_iNg3835t_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_EZoZY4FU_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 20000.0f, 0, m, &cBinop_3I0pA5tD_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_YPujhyNu_sendMessage);
}

void Heavy_TeleportBall::cBinop_4Yxm9i4b_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 0.5f, 0, m, &cBinop_cMmda36N_sendMessage);
}

void Heavy_TeleportBall::cBinop_avgC4Sec_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_WD9dfpnM_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_l4BGClOj_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_0TMKTEwh_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_jLgAdgUB_sendMessage);
}

void Heavy_TeleportBall::cCast_WD9dfpnM_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_a3wzdxTY, HV_BINOP_MULTIPLY, 0, m, &cBinop_a3wzdxTY_sendMessage);
}

void Heavy_TeleportBall::cBinop_BwnrwR5k_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_4z9eXqNG, HV_BINOP_MULTIPLY, 1, m, &cBinop_4z9eXqNG_sendMessage);
}

void Heavy_TeleportBall::cBinop_8Bn25wa4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_UwJ7QkVQ, 1, m, &cVar_UwJ7QkVQ_sendMessage);
}

void Heavy_TeleportBall::cMsg_NSBFkB38_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_avgC4Sec_sendMessage);
}

void Heavy_TeleportBall::cBinop_IdQViv6u_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_WN6f41Wd, HV_BINOP_MULTIPLY, 1, m, &cBinop_WN6f41Wd_sendMessage);
}

void Heavy_TeleportBall::cSend_DgN4stpK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_DaewGX2E_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_rsk5iohB_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_5Un0TOof, 1, m, &cVar_5Un0TOof_sendMessage);
}

void Heavy_TeleportBall::cBinop_4z9eXqNG_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_chKYh1P5_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_7pLBVt7M_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_jDj3BYcv, HV_BINOP_MULTIPLY, 0, m, &cBinop_jDj3BYcv_sendMessage);
}

void Heavy_TeleportBall::cBinop_3I0pA5tD_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 20.0f, 0, m, &cBinop_7pLBVt7M_sendMessage);
}

void Heavy_TeleportBall::cCast_5jymXKEj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_iNg3835t, 0, m, &cVar_iNg3835t_sendMessage);
}

void Heavy_TeleportBall::cCast_f4Nb8o1A_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_SIN, m, &cUnop_3cRJD2s2_sendMessage);
}

void Heavy_TeleportBall::cSend_7Fd4Pgai_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_KTOzvjWU_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cIf_3MraED15_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      break;
    }
    case 1: {
      cIf_onMessage(_c, &Context(_c)->cIf_gmKrHUzz, 0, m, &cIf_gmKrHUzz_sendMessage);
      break;
    }
    default: return;
  }
}

void Heavy_TeleportBall::cMsg_DwdJIIzl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_zeqOyzLe, 0, m, NULL);
}

void Heavy_TeleportBall::cBinop_PhrdMM6s_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_BDUr3vbX, HV_BINOP_MULTIPLY, 1, m, &cBinop_BDUr3vbX_sendMessage);
}

void Heavy_TeleportBall::cCast_9j2mETqQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_COS, m, &cUnop_aJEszMoI_sendMessage);
}

void Heavy_TeleportBall::cBinop_JrT8uNHz_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_ak4jktCh_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_1SZyaFg6_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_BDUr3vbX, HV_BINOP_MULTIPLY, 0, m, &cBinop_BDUr3vbX_sendMessage);
}

void Heavy_TeleportBall::cBinop_SWvtpRvw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 0.5f, 0, m, &cBinop_ZpVcvhyf_sendMessage);
}

void Heavy_TeleportBall::cMsg_gPrspdFP_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_WCPCi3xm_sendMessage);
}

void Heavy_TeleportBall::cVar_4NASTmHD_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_1luQr9I6_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_AW0BMM0X_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_kTfIaSgM, HV_BINOP_MULTIPLY, 0, m, &cBinop_kTfIaSgM_sendMessage);
}

void Heavy_TeleportBall::cUnop_aJEszMoI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_68ZZDHk7_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cVar_7b01B6cc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 100.0f, 0, m, &cBinop_NIKo5Mys_sendMessage);
}

void Heavy_TeleportBall::cBinop_OdvZkXv2_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_gPrspdFP_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_NIKo5Mys_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_OdvZkXv2_sendMessage);
}

void Heavy_TeleportBall::cCast_WJfYA4gx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_4NASTmHD, 0, m, &cVar_4NASTmHD_sendMessage);
}

void Heavy_TeleportBall::cBinop_QLRLnceO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_kTfIaSgM, HV_BINOP_MULTIPLY, 1, m, &cBinop_kTfIaSgM_sendMessage);
}

void Heavy_TeleportBall::cBinop_D0P8zlpk_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 0.5f, 0, m, &cBinop_QLRLnceO_sendMessage);
}

void Heavy_TeleportBall::cCast_V2eO6S8q_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_7b01B6cc, 0, m, &cVar_7b01B6cc_sendMessage);
}

void Heavy_TeleportBall::cUnop_xIhdFq9l_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_sXx4KDPw_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_uue7W9zX_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_TeleportBall::cSend_68ZZDHk7_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_0RC3qZ6X_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_Dmt2TUv1_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_4NASTmHD, 1, m, &cVar_4NASTmHD_sendMessage);
}

void Heavy_TeleportBall::cBinop_BDUr3vbX_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_OpfmYRcE_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_uSFVqd4M_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 0.5f, 0, m, &cBinop_o7xWT5OI_sendMessage);
}

void Heavy_TeleportBall::cBinop_o7xWT5OI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_JcSaZ0Se, HV_BINOP_MULTIPLY, 1, m, &cBinop_JcSaZ0Se_sendMessage);
}

void Heavy_TeleportBall::cCast_ExQzrmU5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_JcSaZ0Se, HV_BINOP_MULTIPLY, 0, m, &cBinop_JcSaZ0Se_sendMessage);
}

void Heavy_TeleportBall::cSystem_RreYApF7_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_kQaB4sRO, HV_BINOP_DIVIDE, 1, m, &cBinop_kQaB4sRO_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_CM6AJiWO_sendMessage);
}

void Heavy_TeleportBall::cMsg_RuhtRkJA_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "samplerate");
  cSystem_onMessage(_c, NULL, 0, m, &cSystem_RreYApF7_sendMessage);
}

void Heavy_TeleportBall::cUnop_V3yV7Th2_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 8.0f, 0, m, &cBinop_7lbKmrM9_sendMessage);
}

void Heavy_TeleportBall::cMsg_MOmMSGtI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  cUnop_onMessage(_c, HV_UNOP_ATAN, m, &cUnop_V3yV7Th2_sendMessage);
}

void Heavy_TeleportBall::cBinop_7lbKmrM9_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_kQaB4sRO, HV_BINOP_DIVIDE, 0, m, &cBinop_kQaB4sRO_sendMessage);
}

void Heavy_TeleportBall::cBinop_kQaB4sRO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_kbDxjCiu, HV_BINOP_MULTIPLY, 1, m, &cBinop_kbDxjCiu_sendMessage);
}

void Heavy_TeleportBall::cBinop_kbDxjCiu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_qS55U3RX_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_9j2mETqQ_sendMessage);
}

void Heavy_TeleportBall::cCast_CM6AJiWO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_MOmMSGtI_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_lLuc2Coj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_7b01B6cc, 1, m, &cVar_7b01B6cc_sendMessage);
}

void Heavy_TeleportBall::cBinop_x5tXHTWO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_kbDxjCiu, HV_BINOP_MULTIPLY, 0, m, &cBinop_kbDxjCiu_sendMessage);
}

void Heavy_TeleportBall::cBinop_tqltjXou_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 20.0f, 0, m, &cBinop_x5tXHTWO_sendMessage);
}

void Heavy_TeleportBall::cMsg_1luQr9I6_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_2vSPNLz8_sendMessage);
}

void Heavy_TeleportBall::cBinop_WCPCi3xm_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_SWvtpRvw, HV_BINOP_MULTIPLY, 1, m, &cBinop_SWvtpRvw_sendMessage);
}

void Heavy_TeleportBall::cBinop_JcSaZ0Se_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_DwdJIIzl_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_qTM5z5He_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_oEhXBjfj, HV_BINOP_MULTIPLY, 0, m, &cBinop_oEhXBjfj_sendMessage);
}

void Heavy_TeleportBall::cBinop_2vSPNLz8_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_uue7W9zX_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_qTM5z5He_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_1SZyaFg6_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_AW0BMM0X_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_cp2ne1Ms_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_ExQzrmU5_sendMessage);
}

void Heavy_TeleportBall::cCast_cp2ne1Ms_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_JrT8uNHz, HV_BINOP_MULTIPLY, 0, m, &cBinop_JrT8uNHz_sendMessage);
}

void Heavy_TeleportBall::cBinop_PSGQhwRx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -1.0f, 0, m, &cBinop_BSLaFgZq_sendMessage);
}

void Heavy_TeleportBall::cBinop_BSLaFgZq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_JrT8uNHz, HV_BINOP_MULTIPLY, 1, m, &cBinop_JrT8uNHz_sendMessage);
}

void Heavy_TeleportBall::cBinop_kTfIaSgM_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_giXoypMQ_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cSend_sXx4KDPw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_zsSUm1O6_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cBinop_ZpVcvhyf_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_xXnfJipY_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cSend_xXnfJipY_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_zbXeDxai_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cCast_qS55U3RX_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_SIN, m, &cUnop_xIhdFq9l_sendMessage);
}

void Heavy_TeleportBall::cCast_tcKEEorq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_hQOfRmBD, 0, m, &cVar_hQOfRmBD_sendMessage);
}

void Heavy_TeleportBall::cMsg_PycDS2L7_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 0.0f, 0, m, &cBinop_1eWhxMXp_sendMessage);
}

void Heavy_TeleportBall::cBinop_1eWhxMXp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_oEhXBjfj, HV_BINOP_MULTIPLY, 1, m, &cBinop_oEhXBjfj_sendMessage);
}

void Heavy_TeleportBall::cBinop_oEhXBjfj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_wn2fbv9f_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cVar_hQOfRmBD_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_V2eO6S8q_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 20000.0f, 0, m, &cBinop_tqltjXou_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_WJfYA4gx_sendMessage);
}

void Heavy_TeleportBall::cMsg_giXoypMQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_nTcQZRMR, 0, m, NULL);
}

void Heavy_TeleportBall::cMsg_wn2fbv9f_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_SDjZH5kX, 0, m, NULL);
}

void Heavy_TeleportBall::cMsg_ak4jktCh_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_L8dmUZEV, 0, m, NULL);
}

void Heavy_TeleportBall::cMsg_OpfmYRcE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_ZPWmyEJc, 0, m, NULL);
}

void Heavy_TeleportBall::cReceive_zsSUm1O6_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_SWvtpRvw, HV_BINOP_MULTIPLY, 0, m, &cBinop_SWvtpRvw_sendMessage);
}

void Heavy_TeleportBall::cCast_6jgn229t_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_w3f8uc9t_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cPack_O4GkEa9c_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_7gMJV94X, 0, m, &cIf_7gMJV94X_sendMessage);
}

void Heavy_TeleportBall::cVar_JbCyKESI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_aOCpubki_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cReceive_FeyyYctG_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -2.0f, 0, m, &cBinop_vEb5K4JT_sendMessage);
}

void Heavy_TeleportBall::cReceive_yGvKUhrs_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cPack_onMessage(_c, &Context(_c)->cPack_VSNNml8h, 1, m, &cPack_VSNNml8h_sendMessage);
  cPack_onMessage(_c, &Context(_c)->cPack_31MA3hV9, 1, m, &cPack_31MA3hV9_sendMessage);
}

void Heavy_TeleportBall::cPack_31MA3hV9_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSwitchcase_mMrL2wGE_onMessage(_c, NULL, 0, m, NULL);
}

void Heavy_TeleportBall::cMsg_th8YOBMO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  cVar_onMessage(_c, &Context(_c)->cVar_sIAxFxzp, 0, m, &cVar_sIAxFxzp_sendMessage);
}

void Heavy_TeleportBall::cReceive_VyIHX9yL_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 0.5f, 0, m, &cBinop_IdQViv6u_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -0.5f, 0, m, &cBinop_hNHiYQmt_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_4Yxm9i4b, HV_BINOP_MULTIPLY, 0, m, &cBinop_4Yxm9i4b_sendMessage);
}

void Heavy_TeleportBall::cCast_xwLFZ7FJ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_nkvPCCYS_sendMessage(_c, 0, m);
}

void Heavy_TeleportBall::cSwitchcase_stmrrEFP_onMessage(HeavyContextInterface *_c, void *o, int letIn, const HvMessage *const m, void *sendMessage) {
  switch (msg_getHash(m, 0)) {
    case 0x3F800000: { // "1.0"
      cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_xwLFZ7FJ_sendMessage);
      break;
    }
    default: {
      break;
    }
  }
}

void Heavy_TeleportBall::cCast_jT2QpOe5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_6jgn229t_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_WVXVm6ue_sendMessage);
}

void Heavy_TeleportBall::cSwitchcase_rPrbrE0V_onMessage(HeavyContextInterface *_c, void *o, int letIn, const HvMessage *const m, void *sendMessage) {
  switch (msg_getHash(m, 0)) {
    case 0x3F800000: { // "1.0"
      cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_jT2QpOe5_sendMessage);
      break;
    }
    default: {
      break;
    }
  }
}

void Heavy_TeleportBall::cIf_7gMJV94X_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      break;
    }
    case 1: {
      cIf_onMessage(_c, &Context(_c)->cIf_gmKrHUzz, 0, m, &cIf_gmKrHUzz_sendMessage);
      break;
    }
    default: return;
  }
}

void Heavy_TeleportBall::cSend_AZ5QPHsp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_7m5EjBJc_sendMessage(_c, 0, m);
}




/*
 * Context Process Implementation
 */

int Heavy_TeleportBall::process(float **inputBuffers, float **outputBuffers, int n) {
  while (hLp_hasData(&inQueue)) {
    hv_uint32_t numBytes = 0;
    ReceiverMessagePair *p = reinterpret_cast<ReceiverMessagePair *>(hLp_getReadBuffer(&inQueue, &numBytes));
    hv_assert(numBytes >= sizeof(ReceiverMessagePair));
    scheduleMessageForReceiver(p->receiverHash, &p->msg);
    hLp_consume(&inQueue);
  }
  const int n4 = n & ~HV_N_SIMD_MASK; // ensure that the block size is a multiple of HV_N_SIMD

  // temporary signal vars
  hv_bufferf_t Bf0, Bf1, Bf2, Bf3, Bf4, Bf5, Bf6, Bf7, Bf8;

  // input and output vars
  hv_bufferf_t O0, O1;

  // declare and init the zero buffer
  hv_bufferf_t ZERO; __hv_zero_f(VOf(ZERO));

  hv_uint32_t nextBlock = blockStartTimestamp;
  for (int n = 0; n < n4; n += HV_N_SIMD) {

    // process all of the messages for this block
    nextBlock += HV_N_SIMD;
    while (mq_hasMessageBefore(&mq, nextBlock)) {
      MessageNode *const node = mq_peek(&mq);
      node->sendMessage(this, node->let, node->m);
      mq_pop(&mq);
    }

    

    // zero output buffers
    __hv_zero_f(VOf(O0));
    __hv_zero_f(VOf(O1));

    // process all signal functions
    __hv_var_k_f(VOf(Bf0), 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    __hv_line_f(&sLine_3BIk5tuC, VOf(Bf1));
    __hv_mul_f(VIf(Bf1), VIf(Bf1), VOf(Bf1));
    __hv_mul_f(VIf(Bf1), VIf(Bf1), VOf(Bf1));
    __hv_var_k_f(VOf(Bf2), 1.5f, 1.5f, 1.5f, 1.5f, 1.5f, 1.5f, 1.5f, 1.5f);
    __hv_varread_f(&sVarf_uZg1LdCU, VOf(Bf3));
    __hv_fma_f(VIf(Bf1), VIf(Bf2), VIf(Bf3), VOf(Bf3));
    __hv_line_f(&sLine_htu4mGqn, VOf(Bf2));
    __hv_var_k_f(VOf(Bf4), 12.0f, 12.0f, 12.0f, 12.0f, 12.0f, 12.0f, 12.0f, 12.0f);
    __hv_mul_f(VIf(Bf2), VIf(Bf4), VOf(Bf4));
    __hv_add_f(VIf(Bf3), VIf(Bf4), VOf(Bf3));
    __hv_phasor_f(&sPhasor_ZYVTR0ew, VIf(Bf3), VOf(Bf3));
    __hv_var_k_f(VOf(Bf2), 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f);
    __hv_sub_f(VIf(Bf3), VIf(Bf2), VOf(Bf2));
    __hv_abs_f(VIf(Bf2), VOf(Bf2));
    __hv_var_k_f(VOf(Bf3), 0.25f, 0.25f, 0.25f, 0.25f, 0.25f, 0.25f, 0.25f, 0.25f);
    __hv_sub_f(VIf(Bf2), VIf(Bf3), VOf(Bf3));
    __hv_var_k_f(VOf(Bf2), 6.28318530718f, 6.28318530718f, 6.28318530718f, 6.28318530718f, 6.28318530718f, 6.28318530718f, 6.28318530718f, 6.28318530718f);
    __hv_mul_f(VIf(Bf3), VIf(Bf2), VOf(Bf2));
    __hv_mul_f(VIf(Bf2), VIf(Bf2), VOf(Bf3));
    __hv_mul_f(VIf(Bf2), VIf(Bf3), VOf(Bf5));
    __hv_mul_f(VIf(Bf5), VIf(Bf3), VOf(Bf3));
    __hv_var_k_f(VOf(Bf6), 0.00783333333333f, 0.00783333333333f, 0.00783333333333f, 0.00783333333333f, 0.00783333333333f, 0.00783333333333f, 0.00783333333333f, 0.00783333333333f);
    __hv_var_k_f(VOf(Bf7), -0.166666666667f, -0.166666666667f, -0.166666666667f, -0.166666666667f, -0.166666666667f, -0.166666666667f, -0.166666666667f, -0.166666666667f);
    __hv_fma_f(VIf(Bf5), VIf(Bf7), VIf(Bf2), VOf(Bf2));
    __hv_fma_f(VIf(Bf3), VIf(Bf6), VIf(Bf2), VOf(Bf2));
    __hv_var_k_f(VOf(Bf6), 4.0f, 4.0f, 4.0f, 4.0f, 4.0f, 4.0f, 4.0f, 4.0f);
    __hv_mul_f(VIf(Bf2), VIf(Bf6), VOf(Bf6));
    __hv_var_k_f(VOf(Bf2), 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    __hv_fma_f(VIf(Bf6), VIf(Bf6), VIf(Bf2), VOf(Bf2));
    __hv_div_f(VIf(Bf0), VIf(Bf2), VOf(Bf2));
    __hv_var_k_f(VOf(Bf0), 0.2f, 0.2f, 0.2f, 0.2f, 0.2f, 0.2f, 0.2f, 0.2f);
    __hv_mul_f(VIf(Bf2), VIf(Bf0), VOf(Bf0));
    __hv_line_f(&sLine_ihNLSowx, VOf(Bf2));
    __hv_zero_f(VOf(Bf6));
    __hv_line_f(&sLine_jkuUC7Tj, VOf(Bf3));
    __hv_line_f(&sLine_HipFyj6H, VOf(Bf7));
    __hv_line_f(&sLine_r8PzBIdi, VOf(Bf5));
    __hv_biquad_f(&sBiquad_s_4kPgLwqC, VIf(Bf0), VIf(Bf2), VIf(Bf6), VIf(Bf3), VIf(Bf7), VIf(Bf5), VOf(Bf5));
    __hv_var_k_f(VOf(Bf7), 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    __hv_var_k_f(VOf(Bf3), 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f);
    __hv_varread_f(&sVarf_itU2SQRj, VOf(Bf6));
    __hv_fma_f(VIf(Bf1), VIf(Bf3), VIf(Bf6), VOf(Bf6));
    __hv_add_f(VIf(Bf6), VIf(Bf4), VOf(Bf4));
    __hv_phasor_f(&sPhasor_3RDIogJb, VIf(Bf4), VOf(Bf4));
    __hv_var_k_f(VOf(Bf6), 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f);
    __hv_sub_f(VIf(Bf4), VIf(Bf6), VOf(Bf6));
    __hv_abs_f(VIf(Bf6), VOf(Bf6));
    __hv_var_k_f(VOf(Bf4), 0.25f, 0.25f, 0.25f, 0.25f, 0.25f, 0.25f, 0.25f, 0.25f);
    __hv_sub_f(VIf(Bf6), VIf(Bf4), VOf(Bf4));
    __hv_var_k_f(VOf(Bf6), 6.28318530718f, 6.28318530718f, 6.28318530718f, 6.28318530718f, 6.28318530718f, 6.28318530718f, 6.28318530718f, 6.28318530718f);
    __hv_mul_f(VIf(Bf4), VIf(Bf6), VOf(Bf6));
    __hv_mul_f(VIf(Bf6), VIf(Bf6), VOf(Bf4));
    __hv_mul_f(VIf(Bf6), VIf(Bf4), VOf(Bf3));
    __hv_mul_f(VIf(Bf3), VIf(Bf4), VOf(Bf4));
    __hv_var_k_f(VOf(Bf2), 0.00783333333333f, 0.00783333333333f, 0.00783333333333f, 0.00783333333333f, 0.00783333333333f, 0.00783333333333f, 0.00783333333333f, 0.00783333333333f);
    __hv_var_k_f(VOf(Bf8), -0.166666666667f, -0.166666666667f, -0.166666666667f, -0.166666666667f, -0.166666666667f, -0.166666666667f, -0.166666666667f, -0.166666666667f);
    __hv_fma_f(VIf(Bf3), VIf(Bf8), VIf(Bf6), VOf(Bf6));
    __hv_fma_f(VIf(Bf4), VIf(Bf2), VIf(Bf6), VOf(Bf6));
    __hv_var_k_f(VOf(Bf2), 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f);
    __hv_mul_f(VIf(Bf6), VIf(Bf2), VOf(Bf2));
    __hv_var_k_f(VOf(Bf6), 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    __hv_fma_f(VIf(Bf2), VIf(Bf2), VIf(Bf6), VOf(Bf6));
    __hv_div_f(VIf(Bf7), VIf(Bf6), VOf(Bf6));
    __hv_var_k_f(VOf(Bf7), 0.66f, 0.66f, 0.66f, 0.66f, 0.66f, 0.66f, 0.66f, 0.66f);
    __hv_min_f(VIf(Bf6), VIf(Bf7), VOf(Bf7));
    __hv_var_k_f(VOf(Bf6), -0.66f, -0.66f, -0.66f, -0.66f, -0.66f, -0.66f, -0.66f, -0.66f);
    __hv_max_f(VIf(Bf7), VIf(Bf6), VOf(Bf6));
    __hv_var_k_f(VOf(Bf7), 0.22f, 0.22f, 0.22f, 0.22f, 0.22f, 0.22f, 0.22f, 0.22f);
    __hv_mul_f(VIf(Bf6), VIf(Bf7), VOf(Bf7));
    __hv_line_f(&sLine_Rqaou0AQ, VOf(Bf6));
    __hv_zero_f(VOf(Bf2));
    __hv_line_f(&sLine_7wTQBa0D, VOf(Bf4));
    __hv_line_f(&sLine_PiRttfo4, VOf(Bf8));
    __hv_line_f(&sLine_oIl3yJVk, VOf(Bf3));
    __hv_biquad_f(&sBiquad_s_oUsyc82S, VIf(Bf7), VIf(Bf6), VIf(Bf2), VIf(Bf4), VIf(Bf8), VIf(Bf3), VOf(Bf3));
    __hv_add_f(VIf(Bf5), VIf(Bf3), VOf(Bf3));
    __hv_var_k_f(VOf(Bf5), 4.0f, 4.0f, 4.0f, 4.0f, 4.0f, 4.0f, 4.0f, 4.0f);
    __hv_mul_f(VIf(Bf0), VIf(Bf5), VOf(Bf5));
    __hv_mul_f(VIf(Bf5), VIf(Bf5), VOf(Bf0));
    __hv_mul_f(VIf(Bf0), VIf(Bf0), VOf(Bf0));
    __hv_var_k_f(VOf(Bf8), 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f);
    __hv_div_f(VIf(Bf0), VIf(Bf8), VOf(Bf8));
    __hv_sub_f(VIf(Bf5), VIf(Bf8), VOf(Bf8));
    __hv_var_k_f(VOf(Bf5), 0.8f, 0.8f, 0.8f, 0.8f, 0.8f, 0.8f, 0.8f, 0.8f);
    __hv_min_f(VIf(Bf8), VIf(Bf5), VOf(Bf5));
    __hv_var_k_f(VOf(Bf8), -0.8f, -0.8f, -0.8f, -0.8f, -0.8f, -0.8f, -0.8f, -0.8f);
    __hv_max_f(VIf(Bf5), VIf(Bf8), VOf(Bf8));
    __hv_line_f(&sLine_X9Xow5lV, VOf(Bf5));
    __hv_zero_f(VOf(Bf0));
    __hv_line_f(&sLine_RdIOWs8G, VOf(Bf4));
    __hv_line_f(&sLine_VtvTj2K0, VOf(Bf2));
    __hv_line_f(&sLine_prekwjOa, VOf(Bf6));
    __hv_biquad_f(&sBiquad_s_xhaLKDWS, VIf(Bf8), VIf(Bf5), VIf(Bf0), VIf(Bf4), VIf(Bf2), VIf(Bf6), VOf(Bf6));
    __hv_add_f(VIf(Bf3), VIf(Bf6), VOf(Bf6));
    __hv_sqrt_f(VIf(Bf1), VOf(Bf3));
    __hv_mul_f(VIf(Bf6), VIf(Bf3), VOf(Bf3));
    __hv_var_k_f(VOf(Bf6), 600.0f, 600.0f, 600.0f, 600.0f, 600.0f, 600.0f, 600.0f, 600.0f);
    __hv_var_k_f(VOf(Bf2), 800.0f, 800.0f, 800.0f, 800.0f, 800.0f, 800.0f, 800.0f, 800.0f);
    __hv_fma_f(VIf(Bf1), VIf(Bf6), VIf(Bf2), VOf(Bf2));
    __hv_var_k_f(VOf(Bf6), 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    __hv_zero_f(VOf(Bf1));
    __hv_max_f(VIf(Bf2), VIf(Bf1), VOf(Bf1));
    __hv_varread_f(&sVarf_VIsgxGDe, VOf(Bf2));
    __hv_mul_f(VIf(Bf1), VIf(Bf2), VOf(Bf2));
    __hv_var_k_f(VOf(Bf1), 6.28318f, 6.28318f, 6.28318f, 6.28318f, 6.28318f, 6.28318f, 6.28318f, 6.28318f);
    __hv_mul_f(VIf(Bf2), VIf(Bf1), VOf(Bf1));
    __hv_varread_f(&sVarf_OJeEqbrq, VOf(Bf4));
    __hv_fms_f(VIf(Bf1), VIf(Bf4), VIf(Bf6), VOf(Bf4));
    __hv_varread_f(&sVarf_jWrRCMWD, VOf(Bf1));
    __hv_zero_f(VOf(Bf0));
    __hv_neq_f(VIf(Bf1), VIf(Bf0), VOf(Bf0));
    __hv_and_f(VIf(Bf4), VIf(Bf0), VOf(Bf0));
    __hv_zero_f(VOf(Bf4));
    __hv_min_f(VIf(Bf0), VIf(Bf4), VOf(Bf4));
    __hv_add_f(VIf(Bf6), VIf(Bf4), VOf(Bf6));
    __hv_varread_f(&sVarf_x0siIQAg, VOf(Bf0));
    __hv_mul_f(VIf(Bf6), VIf(Bf0), VOf(Bf0));
    __hv_mul_f(VIf(Bf3), VIf(Bf0), VOf(Bf0));
    __hv_floor_f(VIf(Bf2), VOf(Bf3));
    __hv_sub_f(VIf(Bf2), VIf(Bf3), VOf(Bf3));
    __hv_var_k_f(VOf(Bf6), 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f);
    __hv_sub_f(VIf(Bf3), VIf(Bf6), VOf(Bf6));
    __hv_abs_f(VIf(Bf6), VOf(Bf6));
    __hv_var_k_f(VOf(Bf3), 0.25f, 0.25f, 0.25f, 0.25f, 0.25f, 0.25f, 0.25f, 0.25f);
    __hv_sub_f(VIf(Bf6), VIf(Bf3), VOf(Bf3));
    __hv_var_k_f(VOf(Bf6), 6.28319f, 6.28319f, 6.28319f, 6.28319f, 6.28319f, 6.28319f, 6.28319f, 6.28319f);
    __hv_mul_f(VIf(Bf3), VIf(Bf6), VOf(Bf6));
    __hv_mul_f(VIf(Bf6), VIf(Bf6), VOf(Bf3));
    __hv_mul_f(VIf(Bf6), VIf(Bf3), VOf(Bf1));
    __hv_mul_f(VIf(Bf1), VIf(Bf3), VOf(Bf3));
    __hv_var_k_f(VOf(Bf5), 0.00784314f, 0.00784314f, 0.00784314f, 0.00784314f, 0.00784314f, 0.00784314f, 0.00784314f, 0.00784314f);
    __hv_var_k_f(VOf(Bf8), 0.166667f, 0.166667f, 0.166667f, 0.166667f, 0.166667f, 0.166667f, 0.166667f, 0.166667f);
    __hv_mul_f(VIf(Bf1), VIf(Bf8), VOf(Bf8));
    __hv_sub_f(VIf(Bf6), VIf(Bf8), VOf(Bf8));
    __hv_fma_f(VIf(Bf3), VIf(Bf5), VIf(Bf8), VOf(Bf8));
    __hv_mul_f(VIf(Bf4), VIf(Bf8), VOf(Bf8));
    __hv_var_k_f(VOf(Bf5), 0.25f, 0.25f, 0.25f, 0.25f, 0.25f, 0.25f, 0.25f, 0.25f);
    __hv_sub_f(VIf(Bf2), VIf(Bf5), VOf(Bf5));
    __hv_floor_f(VIf(Bf5), VOf(Bf2));
    __hv_sub_f(VIf(Bf5), VIf(Bf2), VOf(Bf2));
    __hv_var_k_f(VOf(Bf5), 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f);
    __hv_sub_f(VIf(Bf2), VIf(Bf5), VOf(Bf5));
    __hv_abs_f(VIf(Bf5), VOf(Bf5));
    __hv_var_k_f(VOf(Bf2), 0.25f, 0.25f, 0.25f, 0.25f, 0.25f, 0.25f, 0.25f, 0.25f);
    __hv_sub_f(VIf(Bf5), VIf(Bf2), VOf(Bf2));
    __hv_var_k_f(VOf(Bf5), 6.28319f, 6.28319f, 6.28319f, 6.28319f, 6.28319f, 6.28319f, 6.28319f, 6.28319f);
    __hv_mul_f(VIf(Bf2), VIf(Bf5), VOf(Bf5));
    __hv_mul_f(VIf(Bf5), VIf(Bf5), VOf(Bf2));
    __hv_mul_f(VIf(Bf5), VIf(Bf2), VOf(Bf3));
    __hv_mul_f(VIf(Bf3), VIf(Bf2), VOf(Bf2));
    __hv_var_k_f(VOf(Bf6), 0.00784314f, 0.00784314f, 0.00784314f, 0.00784314f, 0.00784314f, 0.00784314f, 0.00784314f, 0.00784314f);
    __hv_var_k_f(VOf(Bf1), 0.166667f, 0.166667f, 0.166667f, 0.166667f, 0.166667f, 0.166667f, 0.166667f, 0.166667f);
    __hv_mul_f(VIf(Bf3), VIf(Bf1), VOf(Bf1));
    __hv_sub_f(VIf(Bf5), VIf(Bf1), VOf(Bf1));
    __hv_fma_f(VIf(Bf2), VIf(Bf6), VIf(Bf1), VOf(Bf1));
    __hv_mul_f(VIf(Bf4), VIf(Bf1), VOf(Bf1));
    __hv_cpole_f(&sCPole_bJKvXMeV, VIf(Bf0), VIf(ZERO), VIf(Bf8), VIf(Bf1), VOf(Bf1), VOf(Bf8));
    __hv_line_f(&sLine_zeqOyzLe, VOf(Bf1));
    __hv_line_f(&sLine_L8dmUZEV, VOf(Bf0));
    __hv_line_f(&sLine_nTcQZRMR, VOf(Bf4));
    __hv_line_f(&sLine_ZPWmyEJc, VOf(Bf6));
    __hv_line_f(&sLine_SDjZH5kX, VOf(Bf2));
    __hv_biquad_f(&sBiquad_s_tljOXXkI, VIf(Bf8), VIf(Bf1), VIf(Bf0), VIf(Bf4), VIf(Bf6), VIf(Bf2), VOf(Bf2));
    __hv_varread_f(&sVarf_sBOxIsvp, VOf(Bf6));
    __hv_mul_f(VIf(Bf2), VIf(Bf6), VOf(Bf6));
    __hv_add_f(VIf(Bf6), VIf(O0), VOf(O0));
    __hv_add_f(VIf(Bf6), VIf(O1), VOf(O1));

    // save output vars to output buffer
    __hv_store_f(outputBuffers[0]+n, VIf(O0));
    __hv_store_f(outputBuffers[1]+n, VIf(O1));
  }

  blockStartTimestamp = nextBlock;

  return n4; // return the number of frames processed
}

int Heavy_TeleportBall::processInline(float *inputBuffers, float *outputBuffers, int n4) {
  hv_assert(!(n4 & HV_N_SIMD_MASK)); // ensure that n4 is a multiple of HV_N_SIMD

  // define the heavy input buffer for 0 channel(s)
  float **const bIn = NULL;

  // define the heavy output buffer for 2 channel(s)
  float **const bOut = reinterpret_cast<float **>(hv_alloca(2*sizeof(float *)));
  bOut[0] = outputBuffers+(0*n4);
  bOut[1] = outputBuffers+(1*n4);

  int n = process(bIn, bOut, n4);
  return n;
}

int Heavy_TeleportBall::processInlineInterleaved(float *inputBuffers, float *outputBuffers, int n4) {
  hv_assert(n4 & ~HV_N_SIMD_MASK); // ensure that n4 is a multiple of HV_N_SIMD

  // define the heavy input buffer for 0 channel(s), uninterleave
  float *const bIn = NULL;

  // define the heavy output buffer for 2 channel(s)
  float *const bOut = reinterpret_cast<float *>(hv_alloca(2*n4*sizeof(float)));

  int n = processInline(bIn, bOut, n4);

  // interleave the heavy output into the output buffer
  #if HV_SIMD_AVX
  for (int i = 0, j = 0; j < n4; j += 8, i += 16) {
    __m256 x = _mm256_load_ps(bOut+j);    // LLLLLLLL
    __m256 y = _mm256_load_ps(bOut+n4+j); // RRRRRRRR
    __m256 a = _mm256_unpacklo_ps(x, y);  // LRLRLRLR
    __m256 b = _mm256_unpackhi_ps(x, y);  // LRLRLRLR
    _mm256_store_ps(outputBuffers+i, a);
    _mm256_store_ps(outputBuffers+8+i, b);
  }
  #elif HV_SIMD_SSE
  for (int i = 0, j = 0; j < n4; j += 4, i += 8) {
    __m128 x = _mm_load_ps(bOut+j);    // LLLL
    __m128 y = _mm_load_ps(bOut+n4+j); // RRRR
    __m128 a = _mm_unpacklo_ps(x, y);  // LRLR
    __m128 b = _mm_unpackhi_ps(x, y);  // LRLR
    _mm_store_ps(outputBuffers+i, a);
    _mm_store_ps(outputBuffers+4+i, b);
  }
  #elif HV_SIMD_NEON
  // https://community.arm.com/groups/processors/blog/2012/03/13/coding-for-neon--part-5-rearranging-vectors
  for (int i = 0, j = 0; j < n4; j += 4, i += 8) {
    float32x4_t x = vld1q_f32(bOut+j);
    float32x4_t y = vld1q_f32(bOut+n4+j);
    float32x4x2_t z = {x, y};
    vst2q_f32(outputBuffers+i, z); // interleave and store
  }
  #else // HV_SIMD_NONE
  for (int i = 0; i < 2; ++i) {
    for (int j = 0; j < n4; ++j) {
      outputBuffers[i+2*j] = bOut[i*n4+j];
    }
  }
  #endif

  return n;
}
