/**
 * Copyright (c) 2017 Enzien Audio, Ltd.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions, and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the phrase "powered by heavy",
 *    the heavy logo, and a hyperlink to https://enzienaudio.com, all in a visible
 *    form.
 * 
 *   2.1 If the Application is distributed in a store system (for example,
 *       the Apple "App Store" or "Google Play"), the phrase "powered by heavy"
 *       shall be included in the app description or the copyright text as well as
 *       the in the app itself. The heavy logo will shall be visible in the app
 *       itself as well.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

#ifndef _HEAVY_CONTEXT_TELEPORTBALL_HPP_
#define _HEAVY_CONTEXT_TELEPORTBALL_HPP_

// object includes
#include "HeavyContext.hpp"
#include "HvControlIf.h"
#include "HvSignalLine.h"
#include "HvSignalBiquad.h"
#include "HvControlBinop.h"
#include "HvControlVar.h"
#include "HvControlSystem.h"
#include "HvControlSlice.h"
#include "HvSignalVar.h"
#include "HvSignalPhasor.h"
#include "HvControlDelay.h"
#include "HvSignalCPole.h"
#include "HvMath.h"
#include "HvControlPack.h"
#include "HvControlUnop.h"
#include "HvControlCast.h"
#include "HvSignalDel1.h"

class Heavy_TeleportBall : public HeavyContext {

 public:
  Heavy_TeleportBall(double sampleRate, int poolKb=10, int inQueueKb=2, int outQueueKb=0);
  ~Heavy_TeleportBall();

  const char *getName() override { return "TeleportBall"; }
  int getNumInputChannels() override { return 0; }
  int getNumOutputChannels() override { return 2; }

  int process(float **inputBuffers, float **outputBuffer, int n) override;
  int processInline(float *inputBuffers, float *outputBuffer, int n) override;
  int processInlineInterleaved(float *inputBuffers, float *outputBuffer, int n) override;

  int getParameterInfo(int index, HvParameterInfo *info) override;
  struct Parameter {
    struct In {
      enum ParameterIn : hv_uint32_t {
        OUTPUT_GAIN = 0x71E5F6FB, // output_gain
        RAMP_TIME = 0x3F5E99AA, // ramp_time
        STATIONARY_THRESHOLD = 0x13A7A14A, // stationary_threshold
        SWITCH_TIME = 0x5A85518B, // switch_time
        VELOCITY = 0x853B1BE7, // velocity
      };
    };
  };
  struct Event {
    struct In {
      enum EventIn : hv_uint32_t {
        DEPLOY = 0x96BBCF1, // deploy
        OFF = 0x40EFA271, // off
        ON = 0xC5E77367, // on
      };
    };
  };

 private:
  HvTable *getTableForHash(hv_uint32_t tableHash) override;
  void scheduleMessageForReceiver(hv_uint32_t receiverHash, HvMessage *m) override;

  // static sendMessage functions
  static void cMsg_w3f8uc9t_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_82DNXZ6h_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_wwOC2VXz_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSend_PLmSH0Jx_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_ZCYIx7xS_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSend_Ezj8jaOX_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_yqmNPNQU_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_GWVNFmn3_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_Lfx0rAEr_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_dXOfcdId_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_KL7OAU0P_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_tC2Mvb3N_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_vwup37vl_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_o1L1QEGy_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_AYw6kINO_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cUnop_qbtiX9kN_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSystem_LWDaeVqG_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_noz6ptHJ_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_ZesanPwV_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_Sh7ph9ti_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_1jaiDFf6_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_4Lp4ujSd_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_pkyFio8R_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_eBHP9pD1_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_HE2qP74u_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_3M50AAh0_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_vTWqGtOr_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_JltIlWxA_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_em5oHb0X_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_pPtLrQhl_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSend_n5QWtV3R_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_XWmDfgtb_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_Pmm51PBw_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cUnop_2qXEVYyF_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_nN2m0tfE_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_HWAqLTmU_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_aYcLxxxr_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_g4GdS8iX_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_GyYIfoqw_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_FKBBBAR5_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cUnop_HGsW9QNc_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_ifafc6l9_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_gMo7XT1S_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_Z7wKOoio_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_jLvlD3zQ_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_CxLzDeXX_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_NgfxZZit_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_C31TVD7v_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_L9lBm0ue_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_BaBjaeA3_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_tQCKTmWs_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_TKkjGUBE_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_clKMGLFi_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cPack_VSNNml8h_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_OPDQ6QBz_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cIf_gmKrHUzz_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_0tR3sQT5_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_1jUWTkpJ_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_WVXVm6ue_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_js4EiDCr_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_XGPw1LC7_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_7m5EjBJc_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSlice_MwdLVmZT_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSlice_kbEIxkZp_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSlice_R3aZIyfA_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cDelay_aWqnKevK_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cDelay_gcQobKk4_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSlice_sTk8Q7jb_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSwitchcase_mMrL2wGE_onMessage(HeavyContextInterface *, void *, int letIn, const HvMessage *const, void *);
  static void cCast_Bu0o2DHa_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_16KbS7mp_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_i5MUuuye_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_IYWne96E_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cPack_PUqLM2Y4_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_GqdWIOl9_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_ZKfJvczw_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSend_EfhIFd8e_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_A4jfLzwK_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_BhRA7AQu_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_epua4QIc_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_z2yWeDaq_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSlice_hS25Fnl4_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSlice_arzukhbO_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSlice_I8I3o5UP_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cDelay_LKxTSjxa_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cDelay_vMyjUVWR_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_TXSJyZoP_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_82Xq78GC_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cPack_svPqxpLB_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSlice_DCrbpKyx_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSwitchcase_rIYs7urM_onMessage(HeavyContextInterface *, void *, int letIn, const HvMessage *const, void *);
  static void cReceive_DRntEOA2_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_zbXeDxai_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_i7E52hIg_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_0RC3qZ6X_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_sIAxFxzp_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_7Ttef5ai_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_5RkSaPPE_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_Jlz9PQJ1_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_OdipQyG1_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSwitchcase_tblpyBs1_onMessage(HeavyContextInterface *, void *, int letIn, const HvMessage *const, void *);
  static void cSend_aOCpubki_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_dwFCxkVs_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_9Y3DSjfc_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_KTOzvjWU_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_VFrETBtw_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSwitchcase_nwqLQLR2_onMessage(HeavyContextInterface *, void *, int letIn, const HvMessage *const, void *);
  static void cCast_8Q5Yu2PV_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_IMc9rMg6_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_nvAOs0rT_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_Taugy3Cj_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_vUvbIUNA_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_oxFCmiol_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_JioTizAy_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_a4k3tjwo_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_GsrfCnwQ_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_c6dhhbA8_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cUnop_aprhdfzE_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_4uzQdKxl_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_KiNebbwB_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_A4dQsGaq_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_U0DUyy7F_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_bpspVTXl_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_wWrQEgLO_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_QbUEMo9S_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_vEb5K4JT_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_9aTQX5vq_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_Eq1pYkSe_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_qbWvZdC9_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_JOvvd9uB_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_t5WBEN0j_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_ea7ANKOQ_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_uSPalBDP_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_b35Yu7cQ_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_z1w195Xs_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_RpN79y3D_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_TjbKMWQf_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_SKPo7brC_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_697dzppX_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_dFndJ8OR_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_JCalKg8P_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cUnop_UJnUVoHu_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSend_fR1IwSjg_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSend_ruS8JkkS_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_tYT0A4qM_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_LnsWlzJH_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cUnop_BBV4Vopy_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_DcZ77MMQ_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_RFJWeTsA_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_qRFj34tv_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_0znukAQU_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_2hLYzn7R_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSystem_3RPsBVYZ_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_zH6rtcKb_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_QZs27cA0_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_szmGTraU_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_UU9WqzVA_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSend_8wLcaQKq_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_kBhOwSP8_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_3CUSSnbQ_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_cGwgCMrL_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_TaWyDur0_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_DaewGX2E_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_Pk7qACNR_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSystem_OBssJCLw_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_LrUR2CzI_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_2TfT4H55_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_TfDGKBH4_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_VomAosSo_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_tZsSKStj_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_QvTopjNc_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_W84Dt2DB_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cIf_9myDFGq1_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_Nts84Mzp_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_DLtrZPqt_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_C2VS2hKI_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_BlOcrObY_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_67YArhNm_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_e8i7ikdJ_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_N1ffwSv4_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_yqJcAwHz_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_kh3s0X0s_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_Malmsda4_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cPack_iSjhGGK3_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_nkvPCCYS_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_hWrG8tO1_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_TusoicN1_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_2C18Qpy8_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_chKYh1P5_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_pOxlsV5X_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_hhOakXu6_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_sWbdYt1H_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cUnop_3cRJD2s2_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_UwJ7QkVQ_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_cMmda36N_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_jV9Z6zac_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSend_dZ3WBkFJ_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_EZoZY4FU_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_WN6f41Wd_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_jDj3BYcv_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_VEnosIYc_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSystem_uwuGlonE_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_KftY9dVV_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_UQSAciSy_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_LgVp4Rp0_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cUnop_PyHIGV4D_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_w8MTAghT_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_YPujhyNu_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_hNHiYQmt_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_a3wzdxTY_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_IL7rO7KS_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_3adrGwzN_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_0TMKTEwh_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_Rtz4sBqN_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_ogFMhdoM_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cUnop_QFVaU75d_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_zwFOBU5k_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_l4BGClOj_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_j7KZwCkW_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_jLgAdgUB_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_5Un0TOof_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_iNg3835t_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_4Yxm9i4b_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_avgC4Sec_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_WD9dfpnM_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_BwnrwR5k_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_8Bn25wa4_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_NSBFkB38_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_IdQViv6u_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSend_DgN4stpK_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_rsk5iohB_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_4z9eXqNG_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_7pLBVt7M_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_3I0pA5tD_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_5jymXKEj_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_f4Nb8o1A_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSend_7Fd4Pgai_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cIf_3MraED15_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_DwdJIIzl_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_PhrdMM6s_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_9j2mETqQ_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_JrT8uNHz_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_1SZyaFg6_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_SWvtpRvw_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_gPrspdFP_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_4NASTmHD_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_AW0BMM0X_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cUnop_aJEszMoI_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_7b01B6cc_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_OdvZkXv2_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_NIKo5Mys_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_WJfYA4gx_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_QLRLnceO_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_D0P8zlpk_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_V2eO6S8q_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cUnop_xIhdFq9l_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_uue7W9zX_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSend_68ZZDHk7_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_Dmt2TUv1_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_BDUr3vbX_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_uSFVqd4M_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_o7xWT5OI_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_ExQzrmU5_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSystem_RreYApF7_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_RuhtRkJA_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cUnop_V3yV7Th2_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_MOmMSGtI_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_7lbKmrM9_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_kQaB4sRO_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_kbDxjCiu_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_CM6AJiWO_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_lLuc2Coj_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_x5tXHTWO_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_tqltjXou_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_1luQr9I6_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_WCPCi3xm_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_JcSaZ0Se_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_qTM5z5He_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_2vSPNLz8_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_cp2ne1Ms_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_PSGQhwRx_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_BSLaFgZq_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_kTfIaSgM_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSend_sXx4KDPw_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_ZpVcvhyf_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSend_xXnfJipY_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_qS55U3RX_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_tcKEEorq_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_PycDS2L7_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_1eWhxMXp_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_oEhXBjfj_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_hQOfRmBD_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_giXoypMQ_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_wn2fbv9f_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_ak4jktCh_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_OpfmYRcE_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_zsSUm1O6_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_6jgn229t_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cPack_O4GkEa9c_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_JbCyKESI_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_FeyyYctG_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_yGvKUhrs_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cPack_31MA3hV9_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_th8YOBMO_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_VyIHX9yL_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_xwLFZ7FJ_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSwitchcase_stmrrEFP_onMessage(HeavyContextInterface *, void *, int letIn, const HvMessage *const, void *);
  static void cCast_jT2QpOe5_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSwitchcase_rPrbrE0V_onMessage(HeavyContextInterface *, void *, int letIn, const HvMessage *const, void *);
  static void cIf_7gMJV94X_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSend_AZ5QPHsp_sendMessage(HeavyContextInterface *, int, const HvMessage *);

  // objects
  SignalLine sLine_3BIk5tuC;
  SignalLine sLine_htu4mGqn;
  SignalPhasor sPhasor_ZYVTR0ew;
  SignalLine sLine_ihNLSowx;
  SignalLine sLine_jkuUC7Tj;
  SignalLine sLine_HipFyj6H;
  SignalLine sLine_r8PzBIdi;
  SignalBiquad sBiquad_s_4kPgLwqC;
  SignalPhasor sPhasor_3RDIogJb;
  SignalLine sLine_Rqaou0AQ;
  SignalLine sLine_7wTQBa0D;
  SignalLine sLine_PiRttfo4;
  SignalLine sLine_oIl3yJVk;
  SignalBiquad sBiquad_s_oUsyc82S;
  SignalLine sLine_X9Xow5lV;
  SignalLine sLine_RdIOWs8G;
  SignalLine sLine_VtvTj2K0;
  SignalLine sLine_prekwjOa;
  SignalBiquad sBiquad_s_xhaLKDWS;
  SignalCPole sCPole_bJKvXMeV;
  SignalLine sLine_zeqOyzLe;
  SignalLine sLine_L8dmUZEV;
  SignalLine sLine_nTcQZRMR;
  SignalLine sLine_ZPWmyEJc;
  SignalLine sLine_SDjZH5kX;
  SignalBiquad sBiquad_s_tljOXXkI;
  ControlBinop cBinop_ZCYIx7xS;
  ControlBinop cBinop_yqmNPNQU;
  ControlVar cVar_Lfx0rAEr;
  ControlBinop cBinop_dXOfcdId;
  ControlBinop cBinop_KL7OAU0P;
  ControlBinop cBinop_vwup37vl;
  ControlBinop cBinop_ZesanPwV;
  ControlBinop cBinop_Sh7ph9ti;
  ControlBinop cBinop_1jaiDFf6;
  ControlBinop cBinop_pkyFio8R;
  ControlBinop cBinop_HE2qP74u;
  ControlBinop cBinop_3M50AAh0;
  ControlBinop cBinop_vTWqGtOr;
  ControlBinop cBinop_em5oHb0X;
  ControlBinop cBinop_XWmDfgtb;
  ControlBinop cBinop_aYcLxxxr;
  ControlVar cVar_g4GdS8iX;
  ControlVar cVar_FKBBBAR5;
  ControlBinop cBinop_ifafc6l9;
  ControlBinop cBinop_Z7wKOoio;
  ControlBinop cBinop_jLvlD3zQ;
  ControlBinop cBinop_CxLzDeXX;
  ControlBinop cBinop_L9lBm0ue;
  ControlPack cPack_VSNNml8h;
  ControlIf cIf_gmKrHUzz;
  ControlVar cVar_0tR3sQT5;
  ControlSlice cSlice_MwdLVmZT;
  ControlSlice cSlice_kbEIxkZp;
  ControlSlice cSlice_R3aZIyfA;
  ControlDelay cDelay_aWqnKevK;
  ControlDelay cDelay_gcQobKk4;
  ControlSlice cSlice_sTk8Q7jb;
  ControlPack cPack_PUqLM2Y4;
  ControlSlice cSlice_hS25Fnl4;
  ControlSlice cSlice_arzukhbO;
  ControlSlice cSlice_I8I3o5UP;
  ControlDelay cDelay_LKxTSjxa;
  ControlDelay cDelay_vMyjUVWR;
  ControlPack cPack_svPqxpLB;
  ControlSlice cSlice_DCrbpKyx;
  SignalVarf sVarf_sBOxIsvp;
  ControlVar cVar_sIAxFxzp;
  ControlBinop cBinop_7Ttef5ai;
  ControlBinop cBinop_oxFCmiol;
  ControlBinop cBinop_JioTizAy;
  ControlVar cVar_a4k3tjwo;
  ControlBinop cBinop_GsrfCnwQ;
  ControlBinop cBinop_A4dQsGaq;
  ControlBinop cBinop_U0DUyy7F;
  ControlBinop cBinop_QbUEMo9S;
  ControlBinop cBinop_vEb5K4JT;
  ControlVar cVar_9aTQX5vq;
  ControlBinop cBinop_Eq1pYkSe;
  ControlBinop cBinop_qbWvZdC9;
  ControlBinop cBinop_JOvvd9uB;
  ControlBinop cBinop_t5WBEN0j;
  ControlBinop cBinop_ea7ANKOQ;
  ControlBinop cBinop_z1w195Xs;
  ControlBinop cBinop_697dzppX;
  ControlVar cVar_dFndJ8OR;
  ControlBinop cBinop_LnsWlzJH;
  ControlBinop cBinop_DcZ77MMQ;
  ControlBinop cBinop_qRFj34tv;
  ControlBinop cBinop_zH6rtcKb;
  ControlBinop cBinop_QZs27cA0;
  ControlBinop cBinop_szmGTraU;
  SignalVarf sVarf_x0siIQAg;
  ControlBinop cBinop_VomAosSo;
  ControlBinop cBinop_tZsSKStj;
  ControlBinop cBinop_QvTopjNc;
  ControlBinop cBinop_W84Dt2DB;
  ControlIf cIf_9myDFGq1;
  ControlBinop cBinop_Nts84Mzp;
  SignalVarf sVarf_VIsgxGDe;
  ControlBinop cBinop_67YArhNm;
  ControlVar cVar_e8i7ikdJ;
  SignalVarf sVarf_OJeEqbrq;
  SignalVarf sVarf_jWrRCMWD;
  ControlVar cVar_kh3s0X0s;
  SignalVarf sVarf_uZg1LdCU;
  ControlPack cPack_iSjhGGK3;
  ControlBinop cBinop_hWrG8tO1;
  ControlBinop cBinop_sWbdYt1H;
  ControlVar cVar_UwJ7QkVQ;
  ControlBinop cBinop_cMmda36N;
  ControlBinop cBinop_jV9Z6zac;
  ControlBinop cBinop_WN6f41Wd;
  ControlBinop cBinop_jDj3BYcv;
  ControlBinop cBinop_VEnosIYc;
  ControlBinop cBinop_w8MTAghT;
  ControlBinop cBinop_hNHiYQmt;
  ControlBinop cBinop_a3wzdxTY;
  ControlBinop cBinop_IL7rO7KS;
  ControlBinop cBinop_3adrGwzN;
  ControlBinop cBinop_Rtz4sBqN;
  ControlVar cVar_5Un0TOof;
  ControlVar cVar_iNg3835t;
  ControlBinop cBinop_4Yxm9i4b;
  ControlBinop cBinop_avgC4Sec;
  ControlBinop cBinop_BwnrwR5k;
  ControlBinop cBinop_8Bn25wa4;
  ControlBinop cBinop_IdQViv6u;
  ControlBinop cBinop_4z9eXqNG;
  ControlBinop cBinop_7pLBVt7M;
  ControlBinop cBinop_3I0pA5tD;
  ControlIf cIf_3MraED15;
  ControlBinop cBinop_PhrdMM6s;
  ControlBinop cBinop_JrT8uNHz;
  ControlBinop cBinop_SWvtpRvw;
  ControlVar cVar_4NASTmHD;
  ControlVar cVar_7b01B6cc;
  ControlBinop cBinop_OdvZkXv2;
  ControlBinop cBinop_NIKo5Mys;
  ControlBinop cBinop_QLRLnceO;
  ControlBinop cBinop_D0P8zlpk;
  ControlBinop cBinop_Dmt2TUv1;
  ControlBinop cBinop_BDUr3vbX;
  ControlBinop cBinop_uSFVqd4M;
  ControlBinop cBinop_o7xWT5OI;
  ControlBinop cBinop_7lbKmrM9;
  ControlBinop cBinop_kQaB4sRO;
  ControlBinop cBinop_kbDxjCiu;
  ControlBinop cBinop_x5tXHTWO;
  ControlBinop cBinop_tqltjXou;
  ControlBinop cBinop_WCPCi3xm;
  ControlBinop cBinop_JcSaZ0Se;
  ControlBinop cBinop_2vSPNLz8;
  ControlBinop cBinop_PSGQhwRx;
  ControlBinop cBinop_BSLaFgZq;
  ControlBinop cBinop_kTfIaSgM;
  ControlBinop cBinop_ZpVcvhyf;
  ControlBinop cBinop_1eWhxMXp;
  ControlBinop cBinop_oEhXBjfj;
  ControlVar cVar_hQOfRmBD;
  ControlPack cPack_O4GkEa9c;
  ControlVar cVar_JbCyKESI;
  ControlPack cPack_31MA3hV9;
  SignalVarf sVarf_itU2SQRj;
  ControlIf cIf_7gMJV94X;
};

#endif // _HEAVY_CONTEXT_TELEPORTBALL_HPP_
